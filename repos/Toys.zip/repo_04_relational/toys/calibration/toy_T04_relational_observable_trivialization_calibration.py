"""
Repo 4 — T04 Relational Observable Trivialization Calibration

Purpose:
Record how relational observables can trivialize or lose informational
content even before full stress testing.
"""

from repo_04_relational.relational_foundations import Assumption, Concept


# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

assumptions = {
    "reference_fields": Assumption(
        "reference_fields", "relational",
        "Reference entities exist to define relations."
    ),
    "observer_access": Assumption(
        "observer_access", "observer",
        "An observer can identify and compare relational quantities."
    ),
    "stable_distinguishability": Assumption(
        "stable_distinguishability", "gauge",
        "A stable notion of distinguishability exists."
    ),
    "coarse_graining": Assumption(
        "coarse_graining", "observer",
        "Observables are defined only up to coarse-grained resolution."
    ),
}


# ---------------------------------------------------------------------
# Relational observables and failure modes
# ---------------------------------------------------------------------

observables = [
    Concept(
        "fine_grained_relational_distance",
        [
            assumptions["reference_fields"],
            assumptions["observer_access"],
            assumptions["stable_distinguishability"],
        ],
    ),
    Concept(
        "coarse_grained_relational_region",
        [
            assumptions["reference_fields"],
            assumptions["observer_access"],
            assumptions["coarse_graining"],
        ],
    ),
    Concept(
        "invariant_relational_equivalence_class",
        [
            assumptions["stable_distinguishability"],
        ],
    ),
]


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 4 — T04 Relational Observable Trivialization Calibration\n")

    for o in observables:
        print(f"Observable: {o.name}")
        if o.required_assumptions:
            print("  Requires:")
            for a in o.required_assumptions:
                print(f"   - {a.name} [{a.category}]")
        else:
            print("  Requires: (none)")
        print("")

    print(
        "Observation:\n"
        "- Fine-grained relational observables rely on strong distinguishability assumptions.\n"
        "- Coarse-graining tends to erase relational detail, reducing informational content.\n"
        "- Fully invariant relational quantities often collapse into equivalence classes\n"
        "  with little or no capacity to encode information."
    )


if __name__ == "__main__":
    report()
