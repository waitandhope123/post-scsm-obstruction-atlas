"""
Repo 4 — T03 Relational Observables & Gauge Redundancy Calibration

Purpose:
Record how gauge redundancy affects relational observables,
often collapsing distinctions even when quantities are relational.
"""

from repo_04_relational.relational_foundations import Assumption, Concept


# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

assumptions = {
    "full_gauge_invariance": Assumption(
        "full_gauge_invariance", "gauge",
        "Only fully gauge-invariant quantities are physical."
    ),
    "gauge_fixing": Assumption(
        "gauge_fixing", "gauge",
        "Gauge redundancy is partially fixed."
    ),
    "reference_fields": Assumption(
        "reference_fields", "relational",
        "Reference entities exist to define relations."
    ),
    "stable_distinguishability": Assumption(
        "stable_distinguishability", "gauge",
        "A stable notion of distinguishability exists."
    ),
}


# ---------------------------------------------------------------------
# Relational observables under gauge redundancy
# ---------------------------------------------------------------------

observables = [
    Concept(
        "relational_distance_with_gauge_fixing",
        [
            assumptions["reference_fields"],
            assumptions["gauge_fixing"],
        ],
    ),
    Concept(
        "fully_gauge_invariant_relational_distance",
        [
            assumptions["reference_fields"],
            assumptions["full_gauge_invariance"],
        ],
    ),
    Concept(
        "gauge_averaged_relational_quantity",
        [
            assumptions["full_gauge_invariance"],
        ],
    ),
    Concept(
        "bare_gauge_invariant_label",
        [],
    ),
]


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 4 — T03 Relational Observables & Gauge Redundancy Calibration\n")

    for o in observables:
        print(f"Observable: {o.name}")
        if o.required_assumptions:
            print("  Requires:")
            for a in o.required_assumptions:
                print(f"   - {a.name} [{a.category}]")
        else:
            print("  Requires: (none)")
        print("")

    print(
        "Observation:\n"
        "- Relational observables often rely on gauge fixing to remain distinguishable.\n"
        "- Enforcing full gauge invariance typically identifies or averages over\n"
        "  relational distinctions.\n"
        "- Fully invariant quantities tend to collapse into labels with minimal content."
    )


if __name__ == "__main__":
    report()
