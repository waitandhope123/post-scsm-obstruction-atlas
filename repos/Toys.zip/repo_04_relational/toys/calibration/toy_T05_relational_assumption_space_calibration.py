"""
Repo 4 — T05 Relational Assumption Registry Calibration

Purpose:
Catalog all assumptions that appear when defining
relational observables.
"""

# ---------------------------------------------------------------------
# Assumption registry
# ---------------------------------------------------------------------

assumptions_by_category = {
    "background": [
        "preferred_time: A time parameter exists to compare configurations.",
        "fixed_background: Background structures exist implicitly or explicitly.",
    ],
    "gauge": [
        "full_gauge_invariance: Only fully gauge-invariant quantities are physical.",
        "gauge_fixing: Gauge redundancy is partially fixed.",
        "stable_distinguishability: A stable notion of distinguishability exists.",
    ],
    "relational": [
        "reference_fields: Matter or reference entities exist to define relations.",
        "relational_anchor: A stable relational anchor exists.",
    ],
    "observer": [
        "observer_access: An observer can identify, correlate, or compare quantities.",
        "coarse_graining: Observables are defined only up to finite resolution.",
    ],
    "semiclassical": [
        "semiclassical_limit: An effective regime exists where relational observables are stable.",
    ],
}

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 4 — T05 Relational Assumption Registry Calibration\n")

    total = 0
    for category, items in assumptions_by_category.items():
        print(f"Category: {category}")
        for item in items:
            print(f" - {item}")
            total += 1
        print("")

    print(f"Total assumptions recorded: {total}\n")

    print(
        "Note:\n"
        "No assumption is claimed fundamental or non-fundamental here.\n"
        "This registry exists solely to make later assumption removal explicit."
    )


if __name__ == "__main__":
    report()
