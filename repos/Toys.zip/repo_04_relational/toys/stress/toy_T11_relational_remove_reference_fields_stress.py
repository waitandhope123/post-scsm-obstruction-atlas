"""
Repo 4 — T11 Remove Reference Fields (Stress Test)

Purpose:
Test whether relational observables remain definable
once reference fields (rods, clocks, matter anchors) are removed.
"""

# ---------------------------------------------------------------------
# Removed assumptions
# ---------------------------------------------------------------------

removed_assumptions = [
    "reference_fields",
    "relational_anchor",
]

# ---------------------------------------------------------------------
# Still retained (for maximal charity)
# ---------------------------------------------------------------------

retained_assumptions = [
    "observer_access",
    "stable_distinguishability",
]

# ---------------------------------------------------------------------
# Relational observables under stress
# ---------------------------------------------------------------------

relational_observables = {
    "relational_position": ["reference_fields"],
    "relational_time": ["reference_fields"],
    "correlated_relational_quantity": ["reference_fields", "observer_access"],
    "gauge_fixed_relation": ["reference_fields", "gauge_fixing"],
}

# ---------------------------------------------------------------------
# Stress-test evaluation
# ---------------------------------------------------------------------

def report():
    print("\nRepo 4 — T11 Remove Reference Fields (Stress Test)\n")

    print("Removed assumptions:\n")
    for a in removed_assumptions:
        print(f"- {a}")
    print("")

    print("Retained assumptions (for maximal charity):\n")
    for a in retained_assumptions:
        print(f"- {a}")
    print("")

    print("Stress-test failures triggered:\n")

    for obs, reqs in relational_observables.items():
        if "reference_fields" in reqs:
            print(f"• {obs} collapses")
            print("  Missing:")
            print("   - reference_fields [relational]")
            print("  Explanation: Relational observable had no anchor to define relations.\n")

    print(
        "Conclusion:\n"
        "Without reference fields or anchoring structures,\n"
        "relational observables lose operational and definitional meaning.\n\n"
        "Relationality without anchors collapses into unstructured invariance."
    )


if __name__ == "__main__":
    report()
