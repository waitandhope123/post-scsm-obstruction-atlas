## Repo 4 — Relational Observables

### Calibration
```bash
python -m repo_04_relational.toys.calibration.toy_T01_relational_observable_definition_calibration
python -m repo_04_relational.toys.calibration.toy_T02_relational_vs_absolute_quantity_calibration
python -m repo_04_relational.toys.calibration.toy_T03_relational_gauge_redundancy_calibration
python -m repo_04_relational.toys.calibration.toy_T04_relational_observable_trivialization_calibration
python -m repo_04_relational.toys.calibration.toy_T05_relational_assumption_space_calibration
```

### Baseline
```bash
python -m repo_04_relational.toys.baseline.toy_T06_relational_matter_clock_baseline
python -m repo_04_relational.toys.baseline.toy_T07_relational_partial_gauge_fixing_baseline
python -m repo_04_relational.toys.baseline.toy_T08_relational_semiclassical_observables_baseline
python -m repo_04_relational.toys.baseline.toy_T09_relational_partial_observer_dependence_baseline
python -m repo_04_relational.toys.baseline.toy_T10_relational_effective_only_baseline
```

### Stress Tests
```bash
python -m repo_04_relational.toys.stress.toy_T11_relational_remove_reference_fields_stress
python -m repo_04_relational.toys.stress.toy_T12_relational_full_gauge_enforcement_stress
python -m repo_04_relational.toys.stress.toy_T13_relational_dynamical_instability_stress
python -m repo_04_relational.toys.stress.toy_T14_relational_coarse_graining_failure_stress
python -m repo_04_relational.toys.stress.toy_T15_relational_information_dissolution_stress
```

### Synthesis
```bash
python -m repo_04_relational.toys.synthesis.toy_T16_relational_minimal_requirement_set_synthesis
python -m repo_04_relational.toys.synthesis.toy_T17_relational_only_if_reference_structure_synthesis
python -m repo_04_relational.toys.synthesis.toy_T18_relational_only_if_semiclassical_limit_synthesis
python -m repo_04_relational.toys.synthesis.toy_T19_relational_hard_vs_soft_obstruction_map_synthesis
python -m repo_04_relational.toys.synthesis.toy_T20_relational_final_scope_limited_conclusion_synthesis
```
