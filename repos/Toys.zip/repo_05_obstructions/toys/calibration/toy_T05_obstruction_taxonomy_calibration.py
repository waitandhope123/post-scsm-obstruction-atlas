"""
Repo 5 — T05 Obstruction Taxonomy Calibration

Purpose:
Define a taxonomy for classifying obstructions across Repos 1–4.

This toy does NOT introduce new obstructions.
It categorizes previously identified failures into types so the
Obstruction Atlas (T19) can be built without ambiguity.
"""

def taxonomy():
    return {
        "definitional_collapse": {
            "meaning": (
                "The target concept is not even FORMULABLE without a missing primitive "
                "(e.g., time/order, subsystem/region structure, noise interface)."
            ),
            "canonical_examples": [
                "no_persistence_without_time_or_ordering",
                "no_locality_without_region_or_equivalent_structure",
                "no_qec_without_noise_and_recovery_interface",
            ],
        },
        "gauge_identification_trivialization": {
            "meaning": (
                "Enforcing full gauge/diffeomorphism invariance identifies or averages over "
                "distinctions, collapsing informational content into equivalence classes/labels."
            ),
            "canonical_examples": [
                "full_gauge_invariance_trivializes_information",
                "relational_observables_trivialize_under_full_gauge_invariance",
            ],
        },
        "anchoring_failure": {
            "meaning": (
                "Without an invariant anchor (boundary/reference structure), identities, regions, "
                "or operator meanings cannot be stabilized; statements become gauge-relative."
            ),
            "canonical_examples": [
                "remove_reference_structure_triggers_relational_collapse",
                "remove_reference_structure_triggers_persistence_failure",
                "unknown_invariant_anchor_mechanisms",
            ],
        },
        "dynamical_instability": {
            "meaning": (
                "Even if definable at an instant, the structure drifts or mixes under dynamics "
                "(e.g., code subspaces or relational anchors drift under dynamical geometry)."
            ),
            "canonical_examples": [
                "dynamic_geometry_code_instability",
                "relational_dynamical_instability",
                "dynamic_geometry_information_loss",
            ],
        },
        "effective_only_leakage": {
            "meaning": (
                "The concept works only in effective/semiclassical regimes and does not survive "
                "removal of scaffolding; not a new no-go but a classification of scope."
            ),
            "canonical_examples": [
                "standard_qec_effective_only",
                "semiclassical_persistence_effective_only",
                "semiclassical_locality_effective_only",
                "semiclassical_relational_observables_effective_only",
            ],
        },
    }


def report():
    print("\nRepo 5 — T05 Obstruction Taxonomy Calibration\n")

    tax = taxonomy()

    for category, info in tax.items():
        print(f"Category: {category}")
        print(f"  Meaning: {info['meaning']}")
        print("  Canonical examples:")
        for ex in info["canonical_examples"]:
            print(f"   • {ex}")
        print("")

    print(
        "Note:\n"
        "This taxonomy is a naming/organization tool.\n"
        "It does NOT create new obstructions.\n"
        "It ensures later atlas construction (T19) is consistent."
    )


if __name__ == "__main__":
    report()
