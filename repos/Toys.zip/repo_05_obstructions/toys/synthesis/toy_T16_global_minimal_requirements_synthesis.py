"""
Repo 5 — T16 Global Minimal Requirements (Synthesis)

Purpose:
Intersect the minimal requirement sets from Repos 1–4
to identify the global requirement atoms for any notion of
'protected information' in background-free physics.

This toy does not prove existence.
It states what must be definable for the concepts to even be formulable.
"""

def report():
    print("\nRepo 5 — T16 Global Minimal Requirements (Synthesis)\n")

    print("Inputs (from prior repos):")
    print(" • Repo 1 (QGEC): T16 minimal requirements")
    print(" • Repo 2 (Persistence): T16 minimal requirements")
    print(" • Repo 3 (Locality): T16 minimal requirements")
    print(" • Repo 4 (Relational): T16 minimal requirements\n")

    # Intersection-like atoms that recur across repos.
    global_atoms = [
        ("gauge_invariant_formulation", "All claims must be definable under full gauge/diffeomorphism invariance."),
        ("stable_distinguishability", "A stable notion of distinguishing states/configurations exists (inner product / operational separation)."),
        ("structural_interface", "Some structural interface exists to locate/compare/disturb errors or records (time/order, region/subsystem, or equivalent)."),
        ("reference_or_anchor_structure", "Some invariant anchoring/reference structure stabilizes identity/region/operator meaning."),
        ("retrieval_or_comparison_definability", "A notion of retrieval/comparison/decoding exists (even abstractly)."),
        ("stability_under_dynamics", "The structures above remain identifiable under the dynamics (no uncontrolled drift/mixing)."),
    ]

    print("Global requirement atoms (shared spine):\n")
    for name, meaning in global_atoms:
        print(f"- {name}: {meaning}")

    print("\nCross-repo mapping (why each atom appears):\n")

    mapping = {
        "gauge_invariant_formulation": ["Repo1:T16/T20", "Repo2:T16/T20", "Repo3:T16/T20", "Repo4:T16/T20"],
        "stable_distinguishability": ["Repo1:T16", "Repo2:T16", "Repo3:T16", "Repo4:T16"],
        "structural_interface": ["Repo1:T12/T16", "Repo2:T11/T16", "Repo3:T12/T16", "Repo4:T11/T16"],
        "reference_or_anchor_structure": ["Repo1:T18", "Repo2:T17", "Repo3:T18", "Repo4:T17"],
        "retrieval_or_comparison_definability": ["Repo1:T16", "Repo2:T16", "Repo4:T16"],
        "stability_under_dynamics": ["Repo1:T14/T16", "Repo2:T14/T16", "Repo3:T14/T16", "Repo4:T13/T16"],
    }

    for atom, sources in mapping.items():
        print(f"• {atom} ← {', '.join(sources)}")

    print(
        "\nInterpretation rule:\n"
        "If any global atom cannot be defined in a fully background-free,\n"
        "gauge-invariant setting, then 'protected information' notions\n"
        "(QEC-like, persistence-like, locality-like, relational-information-like)\n"
        "cannot be fundamental.\n"
    )


if __name__ == "__main__":
    report()
