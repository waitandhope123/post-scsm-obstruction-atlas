"""
Repo 5 — T09 Exclude Semiclassical Breakdown Failures (Baseline)

Purpose:
Exclude failures that arise solely because a semiclassical,
effective, or perturbative approximation ceases to apply.

These are regime-of-validity limits, not principle-level obstructions.
"""

def report():
    print("\nRepo 5 — T09 Exclude Semiclassical Breakdown Failures (Baseline)\n")

    excluded = [
        "semiclassical_backreaction_breakdown",
        "perturbative_gravity_failure",
        "effective_field_theory_cutoff_violation",
        "approximation_regime_exceeded",
    ]

    print("Excluded failure types (semiclassical breakdown, NOT obstructions):\n")

    for item in excluded:
        print(f" • {item}")

    print(
        "\nRationale:\n"
        "Failures caused by exceeding the domain of validity of\n"
        "semiclassical or effective approximations do not establish\n"
        "fundamental impossibility.\n\n"
        "They indicate only that a description must change,\n"
        "not that the target concept is unformulable in principle.\n\n"
        "Repo 5 tracks only failures that persist independently\n"
        "of approximation scheme."
    )


if __name__ == "__main__":
    report()
