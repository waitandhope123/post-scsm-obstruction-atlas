"""
Repo 5 — T08 Exclude Observer-Limited Pathologies (Baseline)

Purpose:
Exclude failures that arise purely from observer limitations,
finite resolution, or operational access constraints.

These are epistemic limits, not principle-level obstructions.
"""

def report():
    print("\nRepo 5 — T08 Exclude Observer-Limited Pathologies (Baseline)\n")

    excluded = [
        "finite_measurement_resolution_failure",
        "coarse_graining_induced_information_loss",
        "observer_access_limitation",
        "operational_unobservability_only",
    ]

    print("Excluded failure types (observer-limited, NOT obstructions):\n")

    for item in excluded:
        print(f" • {item}")

    print(
        "\nRationale:\n"
        "Failures due solely to finite resolution, coarse-graining,\n"
        "or limited observer access do not establish impossibility.\n\n"
        "They reflect epistemic constraints or practical limitations,\n"
        "not logical or physical no-go results.\n\n"
        "Repo 5 tracks only failures that persist even for idealized\n"
        "observers with unlimited access."
    )


if __name__ == "__main__":
    report()
