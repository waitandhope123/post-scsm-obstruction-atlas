"""
T14 — QGEC Dynamic Geometry Code Instability (Stress Test)

Purpose:
Record a key obstruction mechanism: when geometry is dynamical, the identification
of a "code subspace" and its logical degrees of freedom can become unstable under
the same dynamics that define the system.

This toy:
- does NOT compute quantum gravity
- identifies the instability pattern conceptually
- does NOT attempt a repair (no relational fix here)

It sharpens T11/T13 by focusing on code-subspace stability under dynamical geometry.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Assumptions commonly needed for stable codes
# ---------------------------------------------------------------------

fixed_background = Assumption(
    name="fixed_background",
    description="Background geometry is fixed so supports/subregions are stable.",
    category="background"
)

stable_code_subspace = Assumption(
    name="stable_code_subspace",
    description="A designated code subspace remains well-defined under dynamics/noise.",
    category="gauge"
)

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Stable subsystem structure exists to identify where code lives.",
    category="locality"
)

locality = Assumption(
    name="locality",
    description="A stable notion of locality/support exists.",
    category="locality"
)

# Stress condition:
dynamic_geometry = Assumption(
    name="dynamic_geometry",
    description="Geometry is dynamical; supports/subregions can fluctuate and become relational.",
    category="background"
)

# ---------------------------------------------------------------------
# QEC targets
# ---------------------------------------------------------------------

code_subspace_concept = Concept(
    name="code_subspace_identification",
    requires=[stable_code_subspace, hilbert_factorization]
)

logical_operator_concept = Concept(
    name="logical_operator_identification",
    requires=[hilbert_factorization, locality]
)

# ---------------------------------------------------------------------
# Stress-test evaluation: dynamic geometry vs stability
# ---------------------------------------------------------------------

def evaluate_code_instability_under_dynamic_geometry():
    failures = []

    failures.append(Failure(
        message=(
            "When geometry is dynamical, the identification of spatial subregions (and thus subsystem structure) "
            "can fluctuate. Code-support regions are not fixed objects."
        ),
        missing_assumptions=[fixed_background]
    ))

    failures.append(Failure(
        message=(
            "If the same dynamics that define the theory also move the 'code subspace' (or redefine its embedding), "
            "then code-subspace stability is not guaranteed. The code is not a fixed carrier of logical information."
        ),
        missing_assumptions=[stable_code_subspace]
    ))

    failures.append(Failure(
        message=(
            "Logical operators defined via support or subsystem action can become ill-defined if the mapping "
            "between 'logical' and 'physical' degrees of freedom changes with geometry."
        ),
        missing_assumptions=[hilbert_factorization, locality]
    ))

    failures.append(Failure(
        message=(
            "Even if an effective code exists at one semiclassical configuration, fluctuations between geometries "
            "can mix would-be code and non-code degrees of freedom, undermining protection."
        ),
        missing_assumptions=[fixed_background]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T14 — Dynamic Geometry Code Instability (Stress Test)\n")

    print("Stress condition in force:\n")
    print(f"- {dynamic_geometry.name} [{dynamic_geometry.category}]: {dynamic_geometry.description}\n")

    print("QEC notions at risk:\n")
    for c in [code_subspace_concept, logical_operator_concept]:
        print(f"- {c.name}")
        if c.requires:
            for req in c.requires:
                print(f"    requires: {req.name} [{req.category}]")
    print("")

    print("Instability / obstruction reports:\n")
    failures = evaluate_code_instability_under_dynamic_geometry()
    for f in failures:
        print(f"• {f.message}")
        if f.missing_assumptions:
            print("  What stability would require (often non-fundamental scaffolding):")
            for a in f.missing_assumptions:
                print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does not claim instability is unavoidable in all frameworks.")
    print("It records that dynamical geometry generically threatens stable code-subspace identification.\n")


if __name__ == "__main__":
    report()
