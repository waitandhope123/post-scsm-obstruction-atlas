"""
T13 — QGEC Enforce Full Diffeomorphism Invariance (Stress Test)

Purpose:
Stress-test QEC-like notions under the requirement that ONLY fully
diffeomorphism-invariant (gauge-invariant) structures count as physical.

This toy:
- introduces no quantum gravity model
- enforces a constraint: non-invariant subsystem/locality notions do not count
- does NOT attempt to repair failures with relational substitutes (that is Repo 4 / later toys)

It identifies which QEC components become non-formulable once gauge redundancy is enforced.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Enforced constraint (the stress condition)
# ---------------------------------------------------------------------

full_diffeomorphism_invariance = Assumption(
    name="full_diffeomorphism_invariance",
    description="Only diffeomorphism-invariant / gauge-invariant quantities are physical.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Common QEC scaffolding that is typically NOT diffeomorphism-invariant
# (listed as assumptions that are now disallowed unless reformulated)
# ---------------------------------------------------------------------

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Stable subsystem factorization exists (region/subsystem split).",
    category="locality"
)

locality = Assumption(
    name="locality",
    description="Fixed local support notion exists for errors/operators.",
    category="locality"
)

boundary_structure = Assumption(
    name="boundary_structure",
    description="A fixed asymptotic boundary exists (anchors subregions).",
    category="boundary"
)

preferred_time = Assumption(
    name="preferred_time",
    description="A global/preferred time parameter exists.",
    category="background"
)

# ---------------------------------------------------------------------
# QEC notions we are testing for invariant definability
# ---------------------------------------------------------------------

qec_code_subspace = Concept(
    name="qec_code_subspace",
    requires=[]
)

local_error_operator = Concept(
    name="local_error_operator",
    requires=[locality]
)

noise_model = Concept(
    name="noise_model",
    requires=[preferred_time, hilbert_factorization, locality]
)

recovery_map = Concept(
    name="recovery_map",
    requires=[preferred_time, hilbert_factorization]
)

logical_operator = Concept(
    name="logical_operator_on_code",
    requires=[hilbert_factorization]
)

# ---------------------------------------------------------------------
# Stress-test evaluation
# ---------------------------------------------------------------------

def evaluate_under_full_diff_invariance():
    failures = []

    # 1) Subsystems and factorization
    failures.append(Failure(
        message=(
            "Subsystem factorization is generally not diffeomorphism-invariant. "
            "If only invariant structures count, region-based subsystem splits cannot be assumed."
        ),
        missing_assumptions=[hilbert_factorization]
    ))

    # 2) Local operators / local errors
    failures.append(Failure(
        message=(
            "Local error operators presuppose a fixed notion of locality/support. "
            "Under full diffeomorphism invariance, coordinate-local support is not physical."
        ),
        missing_assumptions=[locality]
    ))

    # 3) Noise model
    failures.append(Failure(
        message=(
            "Standard noise models (channels acting on subsystems over time) rely on "
            "preferred time + subsystem factorization + locality. These are not invariant primitives."
        ),
        missing_assumptions=[preferred_time, hilbert_factorization, locality]
    ))

    # 4) Recovery map
    failures.append(Failure(
        message=(
            "Recovery maps are defined relative to which subsystem was affected and a before/after comparison. "
            "Without invariant subsystems and time, 'recovery' is not formulated."
        ),
        missing_assumptions=[preferred_time, hilbert_factorization]
    ))

    # 5) Logical operators
    failures.append(Failure(
        message=(
            "Logical operators are typically defined by how they act on a code subspace embedded in a larger Hilbert space. "
            "Without an invariant embedding/factorization, operator identification becomes gauge-dependent."
        ),
        missing_assumptions=[hilbert_factorization]
    ))

    # 6) Boundary anchoring (optional but common in holography)
    failures.append(Failure(
        message=(
            "Boundary anchoring can provide invariant subregion structure in special settings (e.g., AdS/CFT). "
            "Without boundary structure, many reconstruction-based QEC notions have no anchor."
        ),
        missing_assumptions=[boundary_structure]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T13 — Enforce Full Diffeomorphism Invariance (Stress Test)\n")

    print("Enforced constraint:\n")
    print(f"- {full_diffeomorphism_invariance.name} [{full_diffeomorphism_invariance.category}]: "
          f"{full_diffeomorphism_invariance.description}\n")

    print("Stress-test result: evaluate which standard QEC notions lose invariant meaning.\n")

    failures = evaluate_under_full_diff_invariance()
    for f in failures:
        print(f"• {f.message}")
        if f.missing_assumptions:
            print("  Non-invariant primitives typically relied upon:")
            for a in f.missing_assumptions:
                print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does NOT attempt relational repairs.")
    print("If anything survives, it must be reformulated invariantly in later work.\n")


if __name__ == "__main__":
    report()
