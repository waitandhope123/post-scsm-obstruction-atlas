"""
T15 — QGEC Gauge Constraint Logical Operator Mixing (Stress Test)

Purpose:
Record an obstruction mechanism: in strongly constrained gauge systems,
the identification of operators and subsystems can become gauge-dependent.
This can mix would-be logical operators with gauge/dressing structure.

This toy:
- does NOT compute constraints
- does NOT model gravity
- enforces the principle: only gauge-invariant operators are physical
- records how that principle destabilizes the notion of "logical operator"

It sharpens T13 by focusing on operator identification under constraints.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Enforced constraint (stress condition)
# ---------------------------------------------------------------------

full_gauge_invariance = Assumption(
    name="full_gauge_invariance",
    description="Only fully gauge-invariant observables/operators are physical.",
    category="gauge"
)

gauge_constraints = Assumption(
    name="gauge_constraints",
    description="Physical states/operators must satisfy nontrivial constraints (Gauss/diffeo/Hamiltonian).",
    category="gauge"
)

# ---------------------------------------------------------------------
# Non-invariant structures QEC often assumes
# ---------------------------------------------------------------------

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Stable subsystem factorization exists.",
    category="locality"
)

local_operator_algebra = Assumption(
    name="local_operator_algebra",
    description="There is a well-defined algebra of local operators acting on subregions/subsystems.",
    category="locality"
)

operator_support = Assumption(
    name="operator_support",
    description="Operators have a definite support region ('acts here, not there').",
    category="locality"
)

# ---------------------------------------------------------------------
# QEC target notions
# ---------------------------------------------------------------------

logical_operator = Concept(
    name="logical_operator",
    requires=[hilbert_factorization, local_operator_algebra, operator_support]
)

dressed_operator = Concept(
    name="gauge_invariant_dressed_operator",
    requires=[full_gauge_invariance, gauge_constraints]
)

# ---------------------------------------------------------------------
# Stress-test evaluation: how constraints induce mixing/ambiguity
# ---------------------------------------------------------------------

def evaluate_operator_mixing_under_constraints():
    failures = []

    failures.append(Failure(
        message=(
            "Under gauge constraints, the physical Hilbert space is a constrained subspace/quotient. "
            "Operators defined on a kinematic factorized Hilbert space may not descend cleanly to the physical space."
        ),
        missing_assumptions=[gauge_constraints]
    ))

    failures.append(Failure(
        message=(
            "Gauge-invariant operators typically require 'dressing' that is nonlocal or reference-anchored. "
            "This undermines definite operator support and can couple would-be logical operators to gauge/dressing data."
        ),
        missing_assumptions=[operator_support, local_operator_algebra]
    ))

    failures.append(Failure(
        message=(
            "Subsystem factorization can fail in constrained systems: edge modes / constraint surfaces correlate degrees of freedom "
            "across any proposed boundary. This spoils the clean separation needed for logical-vs-physical operator definitions."
        ),
        missing_assumptions=[hilbert_factorization]
    ))

    failures.append(Failure(
        message=(
            "Logical operator identification becomes gauge-relative if two different dressings define inequivalent 'same' operator "
            "depending on boundary/reference choices. This induces logical-operator mixing across descriptions."
        ),
        missing_assumptions=[full_gauge_invariance, gauge_constraints]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T15 — Gauge Constraint Logical Operator Mixing (Stress Test)\n")

    print("Enforced constraints:\n")
    for a in [full_gauge_invariance, gauge_constraints]:
        print(f"- {a.name} [{a.category}]: {a.description}")
    print("")

    print("Standard QEC notion under stress:\n")
    print(f"- {logical_operator.name}")
    for req in logical_operator.requires:
        print(f"    relies on: {req.name} [{req.category}]")
    print("")

    print("Gauge-invariant replacement notion (not constructed here):\n")
    print(f"- {dressed_operator.name}")
    for req in dressed_operator.requires:
        print(f"    requires: {req.name} [{req.category}]")
    print("")

    print("Obstruction / mixing reports:\n")
    failures = evaluate_operator_mixing_under_constraints()
    for f in failures:
        print(f"• {f.message}")
        if f.missing_assumptions:
            print("  Non-invariant primitives typically relied upon / destabilized:")
            for a in f.missing_assumptions:
                print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does NOT claim gauge-invariant observables do not exist.")
    print("It claims that standard QEC logical-operator notions do not carry over without substantial reformulation.\n")


if __name__ == "__main__":
    report()
