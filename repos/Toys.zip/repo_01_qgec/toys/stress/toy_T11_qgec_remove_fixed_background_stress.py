"""
T11 — QGEC Remove Fixed Background (Stress Test)

Purpose:
Stress-test QEC-like notions by removing the assumption of a fixed background
spacetime geometry, while keeping all other baseline scaffolding intact.

This toy:
- removes ONLY fixed_background
- does NOT yet enforce full diffeomorphism invariance
- does NOT attempt to repair failures

It identifies which QEC components fail immediately when geometry becomes dynamical.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Assumptions retained (baseline scaffolding except fixed background)
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="An effective time parameter exists.",
    category="background"
)

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Effective subsystem factorization exists.",
    category="locality"
)

locality = Assumption(
    name="locality",
    description="Effective locality exists.",
    category="locality"
)

external_environment = Assumption(
    name="external_environment",
    description="A separable environment exists.",
    category="observer"
)

external_observer_or_agent = Assumption(
    name="external_observer_or_agent",
    description="An operational agent/decoder exists.",
    category="observer"
)

measurement_or_operational_access = Assumption(
    name="measurement_or_operational_access",
    description="Operational access exists.",
    category="observer"
)

stable_inner_product = Assumption(
    name="stable_inner_product",
    description="A stable notion of state distinguishability exists.",
    category="gauge"
)

# Explicitly removed assumption:
fixed_background = Assumption(
    name="fixed_background",
    description="Spacetime geometry is fixed and non-dynamical.",
    category="background"
)

# ---------------------------------------------------------------------
# QEC notions inherited from baselines
# ---------------------------------------------------------------------

logical_code_subspace = Concept(
    name="logical_code_subspace",
    requires=[stable_inner_product, hilbert_factorization]
)

local_noise_model = Concept(
    name="local_noise_model",
    requires=[preferred_time, hilbert_factorization, locality, external_environment]
)

recovery_operation = Concept(
    name="recovery_operation",
    requires=[preferred_time, hilbert_factorization, external_observer_or_agent]
)

# ---------------------------------------------------------------------
# Stress-test: consequences of removing fixed background
# ---------------------------------------------------------------------

def evaluate_without_fixed_background():
    failures = []

    failures.append(Failure(
        message=(
            "Without a fixed background geometry, the notion of 'locality' becomes dynamical "
            "and code support regions are no longer fixed. QEC locality assumptions lose meaning."
        ),
        missing_assumptions=[fixed_background]
    ))

    failures.append(Failure(
        message=(
            "Subsystem factorization tied to spatial regions becomes ambiguous when geometry fluctuates."
        ),
        missing_assumptions=[fixed_background]
    ))

    failures.append(Failure(
        message=(
            "Local noise models presuppose fixed causal structure; dynamical geometry undermines this."
        ),
        missing_assumptions=[fixed_background]
    ))

    failures.append(Failure(
        message=(
            "Recovery operations depend on identifying which degrees of freedom were affected; "
            "this identification becomes frame- and geometry-dependent without a fixed background."
        ),
        missing_assumptions=[fixed_background]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T11 — Remove Fixed Background (Stress Test)\n")

    print("Assumptions retained (fixed background REMOVED):\n")
    retained = [
        preferred_time,
        hilbert_factorization,
        locality,
        external_environment,
        external_observer_or_agent,
        measurement_or_operational_access,
        stable_inner_product
    ]
    for a in retained:
        print(f"- {a.name} [{a.category}]")
    print("")

    print("Stress-test failures triggered by removing fixed background:\n")
    failures = evaluate_without_fixed_background()
    for f in failures:
        print(f"• {f.message}")
        print("  Missing / violated assumption:")
        for a in f.missing_assumptions:
            print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does NOT yet enforce full diffeomorphism invariance.")
    print("It shows that many QEC notions already become unstable when geometry is dynamical.\n")


if __name__ == "__main__":
    report()
