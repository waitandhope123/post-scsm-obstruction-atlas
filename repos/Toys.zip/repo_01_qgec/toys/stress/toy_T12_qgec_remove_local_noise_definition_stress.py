"""
T12 — QGEC Remove Local Noise Definition (Stress Test)

Purpose:
Stress-test QEC-like notions by removing the ability to define "local noise"
in the standard way.

This toy removes the *noise model interface* rather than removing time or
enforcing diffeomorphism invariance.

Key idea:
If "noise" is undefined, then "error correction" is undefined.

This toy:
- does NOT attempt to repair the noise definition
- records which QEC components become non-formulable
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Retained scaffolding (we keep much of the baseline world)
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="An effective time parameter exists.",
    category="background"
)

stable_inner_product = Assumption(
    name="stable_inner_product",
    description="A stable notion of state distinguishability exists.",
    category="gauge"
)

external_observer_or_agent = Assumption(
    name="external_observer_or_agent",
    description="An operational agent/decoder exists.",
    category="observer"
)

measurement_or_operational_access = Assumption(
    name="measurement_or_operational_access",
    description="Operational access exists to characterize disturbances.",
    category="observer"
)

# Removed interface assumptions:
hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Stable subsystem factorization exists.",
    category="locality"
)

locality = Assumption(
    name="locality",
    description="A meaningful locality notion exists to define support of errors.",
    category="locality"
)

external_environment = Assumption(
    name="external_environment",
    description="A separable environment exists that can be traced out.",
    category="observer"
)

# ---------------------------------------------------------------------
# QEC components that depend on a noise model
# ---------------------------------------------------------------------

code_subspace = Concept(
    name="code_subspace",
    requires=[stable_inner_product]
)

noise_channel = Concept(
    name="noise_channel_cptp_or_effective",
    requires=[preferred_time, measurement_or_operational_access]
)

local_noise_model = Concept(
    name="local_noise_model_k_local_or_geometric",
    requires=[preferred_time, hilbert_factorization, locality, external_environment]
)

recovery_operation = Concept(
    name="recovery_operation",
    requires=[preferred_time, external_observer_or_agent]
)

qec_statement = Concept(
    name="qec_statement_corrects_error_set_E",
    requires=[preferred_time, local_noise_model, recovery_operation]
)

# ---------------------------------------------------------------------
# Stress-test: remove local noise definability
# ---------------------------------------------------------------------

def evaluate_without_local_noise_definability():
    failures = []

    failures.append(Failure(
        message=(
            "Local noise model is undefined without subsystem factorization + locality + environment split."
        ),
        missing_assumptions=[hilbert_factorization, locality, external_environment]
    ))

    failures.append(Failure(
        message=(
            "Without a local-noise model, the set of correctable errors E cannot be specified in the usual way."
        ),
        missing_assumptions=[hilbert_factorization, locality]
    ))

    failures.append(Failure(
        message=(
            "Without a specified error model/interface, 'recovery' loses operational meaning: "
            "recover from what disturbance class?"
        ),
        missing_assumptions=[hilbert_factorization, locality, external_environment]
    ))

    failures.append(Failure(
        message=(
            "The core QEC claim 'this code corrects this noise' collapses if 'noise' is not well-defined."
        ),
        missing_assumptions=[hilbert_factorization, locality, external_environment]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T12 — Remove Local Noise Definition (Stress Test)\n")

    print("Retained scaffolding (but local noise definability is removed):\n")
    retained = [preferred_time, stable_inner_product, external_observer_or_agent, measurement_or_operational_access]
    for a in retained:
        print(f"- {a.name} [{a.category}]")
    print("")

    print("Removed interface assumptions (explicitly not available):\n")
    removed = [hilbert_factorization, locality, external_environment]
    for a in removed:
        print(f"- {a.name} [{a.category}]")
    print("")

    print("Stress-test failures:\n")
    failures = evaluate_without_local_noise_definability()
    for f in failures:
        print(f"• {f.message}")
        if f.missing_assumptions:
            print("  Missing assumptions to even formulate:")
            for a in f.missing_assumptions:
                print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does NOT claim all notions of disturbance are impossible.")
    print("It claims that standard QEC depends on a well-defined noise model interface.\n")


if __name__ == "__main__":
    report()
