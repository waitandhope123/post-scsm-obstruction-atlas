"""
T09 — QGEC Semiclassical Gravity Limit (Baseline)

Purpose:
Test what remains of QEC-like protection in a semiclassical gravity setting
when fixed boundary structure is NOT assumed.

This toy:
- assumes a semiclassical regime (approximate geometry + effective locality)
- does NOT assume a fixed asymptotic boundary / holographic dual
- remains baseline: no full diffeomorphism invariance enforcement

It exists to identify which holographic-QEC components collapse without boundary anchoring.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Semiclassical baseline assumptions (NO boundary)
# ---------------------------------------------------------------------

semiclassical_limit = Assumption(
    name="semiclassical_limit",
    description="Approximate classical geometry exists with quantum fields on it.",
    category="semiclassical"
)

preferred_time = Assumption(
    name="preferred_time",
    description="An effective time parameter exists (semiclassical notion of evolution).",
    category="background"
)

locality = Assumption(
    name="locality",
    description="Effective locality exists (approximate causal structure).",
    category="locality"
)

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Effective subsystem factorization exists (approximate region decomposition).",
    category="locality"
)

external_observer_or_agent = Assumption(
    name="external_observer_or_agent",
    description="An operational decoder/agent exists (effective description).",
    category="observer"
)

stable_inner_product = Assumption(
    name="stable_inner_product",
    description="A stable notion of distinguishability exists in the effective regime.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Candidate QEC-like components people might hope survive semiclassically
# ---------------------------------------------------------------------

effective_code_subspace = Concept(
    name="effective_code_subspace",
    requires=[semiclassical_limit, stable_inner_product]
)

effective_local_noise_model = Concept(
    name="effective_local_noise_model",
    requires=[preferred_time, locality, hilbert_factorization]
)

effective_recovery = Concept(
    name="effective_recovery_operation",
    requires=[preferred_time, hilbert_factorization, external_observer_or_agent]
)

# Components that are specifically boundary-anchored (expected to fail here)
boundary_factorization = Concept(
    name="boundary_subregion_factorization",
    requires=[]  # intentionally empty: boundary is absent, so this is not available
)

entanglement_wedge_reconstruction = Concept(
    name="entanglement_wedge_reconstruction",
    requires=[]  # boundary absent
)

# ---------------------------------------------------------------------
# Diagnostic: what collapses without boundary structure?
# ---------------------------------------------------------------------

def evaluate_without_boundary():
    failures = []

    failures.append(Failure(
        message="Boundary subregion factorization is unavailable without fixed boundary structure.",
        missing_assumptions=[Assumption(
            name="boundary_structure",
            description="A fixed asymptotic boundary exists.",
            category="boundary"
        )]
    ))

    failures.append(Failure(
        message="Entanglement wedge reconstruction is not formulable without boundary anchoring and subregion data.",
        missing_assumptions=[Assumption(
            name="boundary_structure",
            description="A fixed asymptotic boundary exists.",
            category="boundary"
        )]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T09 — Semiclassical Gravity Limit (Baseline, No Fixed Boundary)\n")

    print("Assumptions in force (semiclassical, no boundary):\n")
    assumptions = [
        semiclassical_limit,
        preferred_time,
        locality,
        hilbert_factorization,
        external_observer_or_agent,
        stable_inner_product
    ]
    for a in assumptions:
        print(f"- {a.name} [{a.category}]: {a.description}")
    print("")

    print("QEC-like components that are still formulable (effective only):\n")
    for c in [effective_code_subspace, effective_local_noise_model, effective_recovery]:
        print(f"- {c.name}")
        for req in c.requires:
            print(f"    requires: {req.name} [{req.category}]")
    print("")

    print("Holographic/boundary-anchored components that collapse without boundary:\n")
    failures = evaluate_without_boundary()
    for f in failures:
        print(f"• {f.message}")
        if f.missing_assumptions:
            print("  Missing:")
            for a in f.missing_assumptions:
                print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does NOT claim effective QEC-like notions are fundamental.")
    print("It distinguishes semiclassical-effective definability from boundary-anchored holographic constructions.\n")


if __name__ == "__main__":
    report()
