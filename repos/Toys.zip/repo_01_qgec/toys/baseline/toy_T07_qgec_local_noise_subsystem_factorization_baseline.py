"""
T07 — QGEC Local Noise vs Subsystem Factorization (Baseline)

Purpose:
Show that standard local-noise QEC formulations rely critically on a stable
subsystem structure (Hilbert-space factorization or equivalent).

This is still a baseline setting:
- fixed background
- preferred time
but we explicitly *stress* the subsystem assumption by toggling it.

This toy:
- does NOT attempt quantum gravity
- does NOT enforce diffeomorphism invariance
- does NOT claim impossibility
It only identifies which QEC notions become undefined when factorization is absent.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Assumptions (baseline world)
# ---------------------------------------------------------------------

fixed_background = Assumption(
    name="fixed_background",
    description="Spacetime geometry is fixed and non-dynamical.",
    category="background"
)

preferred_time = Assumption(
    name="preferred_time",
    description="A global or preferred time parameter exists.",
    category="background"
)

locality = Assumption(
    name="locality",
    description="There is a meaningful local notion (spatial/casual) for where errors act.",
    category="locality"
)

external_environment = Assumption(
    name="external_environment",
    description="A separable environment exists that introduces noise.",
    category="observer"
)

external_observer_or_agent = Assumption(
    name="external_observer_or_agent",
    description="An agent/decoder exists to perform recovery operations.",
    category="observer"
)

measurement_or_operational_access = Assumption(
    name="measurement_or_operational_access",
    description="Operational access exists to characterize disturbances or outcomes.",
    category="observer"
)

stable_inner_product = Assumption(
    name="stable_inner_product",
    description="A stable Hilbert-space inner product exists.",
    category="gauge"
)

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Total Hilbert space factorizes into stable subsystems.",
    category="locality"
)

# ---------------------------------------------------------------------
# QEC notions that typically depend on factorization
# ---------------------------------------------------------------------

local_noise_model = Concept(
    name="local_noise_model_k_local_or_geometric",
    requires=[preferred_time, hilbert_factorization, locality, external_environment]
)

erasure_on_subsystem = Concept(
    name="erasure_of_subsystem_A",
    requires=[preferred_time, hilbert_factorization]
)

partial_trace_environment = Concept(
    name="trace_out_environment",
    requires=[preferred_time, hilbert_factorization, external_environment]
)

syndrome_measurement = Concept(
    name="syndrome_measurement",
    requires=[preferred_time, measurement_or_operational_access, external_observer_or_agent]
)

recovery_operation = Concept(
    name="recovery_operation",
    requires=[preferred_time, hilbert_factorization, external_observer_or_agent]
)

# ---------------------------------------------------------------------
# Toggle: with vs without factorization
# ---------------------------------------------------------------------

def evaluate_world(has_factorization: bool):
    """
    Returns:
      (ok: bool, failures: list[Failure])
    """
    failures = []

    if not has_factorization:
        failures.append(Failure(
            message="Local noise model is not formulable without a stable subsystem structure (no support notion).",
            missing_assumptions=[hilbert_factorization]
        ))
        failures.append(Failure(
            message="Erasure / loss of a subsystem cannot be stated without identifying the subsystem.",
            missing_assumptions=[hilbert_factorization]
        ))
        failures.append(Failure(
            message="Tracing out an environment presumes a system/environment split (factorization).",
            missing_assumptions=[hilbert_factorization]
        ))
        failures.append(Failure(
            message="Recovery maps are defined relative to which degrees of freedom were affected/erased; without subsystems this is undefined.",
            missing_assumptions=[hilbert_factorization]
        ))

        return False, failures

    return True, []


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T07 — Local Noise vs Subsystem Factorization (Baseline)\n")

    print("Baseline setting: fixed background + preferred time, but we toggle factorization.\n")

    for has_factorization in [True, False]:
        label = "WITH factorization" if has_factorization else "WITHOUT factorization"
        print(f"World: {label}")
        ok, failures = evaluate_world(has_factorization)

        if ok:
            print("  Result: QEC local-noise notions are formulable.")
            print("  Enabled components:")
            for c in [local_noise_model, erasure_on_subsystem, partial_trace_environment, syndrome_measurement, recovery_operation]:
                print(f"   - {c.name}")
        else:
            print("  Result: FAIL (key QEC notions become undefined).")
            for f in failures:
                print(f"   • {f.message}")
                if f.missing_assumptions:
                    print("     Missing:")
                    for a in f.missing_assumptions:
                        print(f"       - {a.name} [{a.category}]")
        print("")

    print("Note: This is a baseline diagnostic, not a quantum-gravity claim.\n")


if __name__ == "__main__":
    report()
