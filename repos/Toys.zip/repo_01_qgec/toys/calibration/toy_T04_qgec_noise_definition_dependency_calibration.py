"""
T04 — QGEC Noise Definition Dependency Calibration

Purpose:
Enumerate common meanings of "noise" used in QEC discussions and record what
structural assumptions each meaning requires.

This toy:
- draws NO conclusions about quantum gravity
- does NOT model dynamics
- does NOT assert any notion of noise is fundamental

It only prevents the key equivocation:
  if "noise" is undefined, then "error correction" is undefined.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Structural assumptions that "noise" definitions typically require
# ---------------------------------------------------------------------

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Total Hilbert space factorizes into stable subsystems (system vs environment, or regions).",
    category="locality"
)

locality = Assumption(
    name="locality",
    description="There is a meaningful local notion (spatial/casual) to say noise acts 'here not there'.",
    category="locality"
)

preferred_time = Assumption(
    name="preferred_time",
    description="There is a time parameter to define evolution, channels, and 'after noise'.",
    category="background"
)

external_environment = Assumption(
    name="external_environment",
    description="There exists a separable environment that can be traced out / ignored operationally.",
    category="observer"
)

measurement_or_operational_access = Assumption(
    name="measurement_or_operational_access",
    description="There exists an operational scheme to characterize disturbances (tomography, statistics, etc.).",
    category="observer"
)

semiclassical_limit = Assumption(
    name="semiclassical_limit",
    description="Approximate fixed causal structure exists to define local interactions and effective channels.",
    category="semiclassical"
)

# ---------------------------------------------------------------------
# Common "noise" notions (as Concepts with declared structural dependencies)
# ---------------------------------------------------------------------

noise_notions = []

noise_notions.append(
    Concept(
        name="cptp_channel_noise",
        requires=[preferred_time, hilbert_factorization, measurement_or_operational_access]
    )
)

noise_notions.append(
    Concept(
        name="local_noise_model_k_local_or_geometric",
        requires=[preferred_time, hilbert_factorization, locality]
    )
)

noise_notions.append(
    Concept(
        name="system_environment_coupling_trace_out_environment",
        requires=[preferred_time, hilbert_factorization, external_environment]
    )
)

noise_notions.append(
    Concept(
        name="stochastic_error_model_pauli_depolarizing_like",
        requires=[preferred_time, hilbert_factorization, measurement_or_operational_access]
    )
)

noise_notions.append(
    Concept(
        name="effective_semiclassical_noise_from_gravity_or_fields",
        requires=[preferred_time, semiclassical_limit, locality]
    )
)

# ---------------------------------------------------------------------
# Calibration failures: when "noise" is invoked without its prerequisites
# ---------------------------------------------------------------------

def formulate_noise_without_structure_check():
    """
    This is a deliberately blunt checklist.

    It highlights that:
    - Without time, a 'channel' is not defined.
    - Without factorization, 'system' vs 'environment' is not defined.
    - Without locality, 'local noise' is not defined.
    """
    failures = []

    failures.append(Failure(
        message="If preferred_time is absent, channel-based noise (CPTP evolution, before/after) is not formulable.",
        missing_assumptions=[preferred_time]
    ))

    failures.append(Failure(
        message="If hilbert_space_factorization is absent, 'system' vs 'environment' and localized erasures are not formulable.",
        missing_assumptions=[hilbert_factorization]
    ))

    failures.append(Failure(
        message="If locality is absent, 'local noise' and geometric support conditions are not formulable.",
        missing_assumptions=[locality]
    ))

    failures.append(Failure(
        message="If operational access is absent, 'noise strength' and 'error rates' are not empirically or operationally meaningful.",
        missing_assumptions=[measurement_or_operational_access]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T04 — Noise Definition Dependency Calibration\n")

    print("Noise notions (names + required assumptions to even speak about them):\n")
    for n in noise_notions:
        print(f"- {n.name}")
        if n.requires:
            for req in n.requires:
                print(f"    requires: {req.name} [{req.category}]")
        else:
            print("    requires: (none)")
    print("")

    print("Dependency failure modes (calibration checklist):\n")
    failures = formulate_noise_without_structure_check()
    for f in failures:
        print(f"• {f.message}")
        if f.missing_assumptions:
            print("  Missing assumptions to even formulate:")
            for a in f.missing_assumptions:
                print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does NOT claim noise is impossible fundamentally.")
    print("It records that most uses of 'noise' silently assume time + subsystem structure + (often) locality.\n")


if __name__ == "__main__":
    report()
