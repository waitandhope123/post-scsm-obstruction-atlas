"""
T01 — QGEC Definition Calibration

Purpose:
Enumerate the major meanings of "error correction" used in physics and
explicitly record the structural assumptions each meaning requires.

This file:
- draws NO conclusions
- performs NO stress tests
- proves NOTHING

Its only job is to prevent definitional equivocation later.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Structural assumptions (declared, not justified)
# ---------------------------------------------------------------------

fixed_background = Assumption(
    name="fixed_background",
    description="Spacetime geometry is fixed and non-dynamical.",
    category="background"
)

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Total Hilbert space factorizes into stable subsystems.",
    category="locality"
)

locality = Assumption(
    name="locality",
    description="Well-defined notion of spatial or causal locality exists.",
    category="locality"
)

external_environment = Assumption(
    name="external_environment",
    description="A separable environment exists to which noise can be attributed.",
    category="observer"
)

preferred_time = Assumption(
    name="preferred_time",
    description="A global or preferred time parameter exists.",
    category="background"
)

boundary_structure = Assumption(
    name="boundary_structure",
    description="A fixed boundary or asymptotic region exists.",
    category="boundary"
)

semiclassical_limit = Assumption(
    name="semiclassical_limit",
    description="Quantum fields propagate on approximately classical spacetime.",
    category="semiclassical"
)

gauge_fixing = Assumption(
    name="gauge_fixing",
    description="Gauge redundancy is partially or fully fixed.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Definitions of "error correction" (as concepts, not implementations)
# ---------------------------------------------------------------------

definitions = []

definitions.append(
    Concept(
        name="shannon_error_correction",
        requires=[
            preferred_time,
            external_environment,
            hilbert_factorization
        ]
    )
)

definitions.append(
    Concept(
        name="quantum_stabilizer_codes",
        requires=[
            hilbert_factorization,
            locality,
            preferred_time
        ]
    )
)

definitions.append(
    Concept(
        name="subsystem_codes",
        requires=[
            hilbert_factorization,
            locality,
            external_environment
        ]
    )
)

definitions.append(
    Concept(
        name="decoherence_free_subspaces",
        requires=[
            hilbert_factorization,
            external_environment
        ]
    )
)

definitions.append(
    Concept(
        name="holographic_error_correction_ads_cft",
        requires=[
            boundary_structure,
            semiclassical_limit,
            gauge_fixing
        ]
    )
)

definitions.append(
    Concept(
        name="emergent_gravitational_code_subspace",
        requires=[
            semiclassical_limit,
            boundary_structure,
            hilbert_factorization
        ]
    )
)

# ---------------------------------------------------------------------
# Reporting (descriptive only)
# ---------------------------------------------------------------------

def report_definitions(definitions):
    print("\nQGEC Definition Calibration\n")
    for concept in definitions:
        print(f"Definition: {concept.name}")
        if concept.requires:
            print("  Requires:")
            for req in concept.requires:
                print(f"   - {req.name} [{req.category}]")
        else:
            print("  Requires: (none declared)")
        print("")

if __name__ == "__main__":
    report_definitions(definitions)
