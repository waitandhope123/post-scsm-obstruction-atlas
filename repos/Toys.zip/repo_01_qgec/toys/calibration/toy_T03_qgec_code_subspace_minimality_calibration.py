"""
T03 — QGEC Code Subspace Minimality Calibration

Purpose:
Make explicit what minimum structural ingredients are required for the notion of a
"code subspace" to be meaningful at all.

This toy:
- draws NO conclusions about quantum gravity
- does NOT attempt to build a code
- does NOT assume a tensor factorization unless declared

It only exposes the dependency chain:
  "code subspace" -> "encoding map" -> "logical distinguishability" -> "addressability"
and records which assumptions are needed to even formulate these.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Structural assumptions that commonly sneak in when people say "code subspace"
# ---------------------------------------------------------------------

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Total Hilbert space factorizes into stable subsystems (or an equivalent fixed subsystem structure).",
    category="locality"
)

preferred_time = Assumption(
    name="preferred_time",
    description="A time parameter exists to compare 'before encoding' and 'after noise/recovery'.",
    category="background"
)

external_observer_or_agent = Assumption(
    name="external_observer_or_agent",
    description="There exists an operational notion of an agent/decoder that can act or condition on outcomes.",
    category="observer"
)

stable_inner_product = Assumption(
    name="stable_inner_product",
    description="A stable Hilbert-space inner product is meaningful for distinguishing states (no moving target via gauge/constraints).",
    category="gauge"
)

# Note: We are not yet enforcing diffeomorphism invariance here.
# That comes in stress tests later. This is minimal definitional bookkeeping.

# ---------------------------------------------------------------------
# Minimal "components" of a code-subspace claim (conceptual objects)
# ---------------------------------------------------------------------

code_subspace = Concept(
    name="code_subspace",
    requires=[stable_inner_product]
)

encoding_map = Concept(
    name="encoding_map_isometry_or_inclusion",
    requires=[stable_inner_product, external_observer_or_agent]
)

logical_alphabet = Concept(
    name="nontrivial_logical_state_space",
    requires=[stable_inner_product]
)

logical_addressability = Concept(
    name="logical_addressability_decode_readout",
    requires=[hilbert_factorization, external_observer_or_agent]
)

recovery_map = Concept(
    name="recovery_channel_decoder",
    requires=[preferred_time, hilbert_factorization, external_observer_or_agent]
)

# ---------------------------------------------------------------------
# Minimality tests (calibration-style checklists, not theorems)
# ---------------------------------------------------------------------

def check_code_subspace_minimality():
    """
    Returns a list of Failure objects describing why "code subspace"
    collapses if certain structural ingredients are absent.

    This is deliberately conservative: it flags what must be *formulated*,
    not what must be *true in nature*.
    """
    failures = []

    # 1) Subspace talk without a stable notion of distinguishability
    failures.append(Failure(
        message=(
            "Without a stable inner product / state distinguishability structure, "
            "'subspace' is not a usable carrier of logical information."
        ),
        missing_assumptions=[stable_inner_product]
    ))

    # 2) Encoding without an operational notion of mapping/identification
    failures.append(Failure(
        message=(
            "Without an encoding map (even abstractly), 'code subspace' risks being a label "
            "with no connection to physical degrees of freedom."
        ),
        missing_assumptions=[external_observer_or_agent]
    ))

    # 3) Logical addressability usually sneaks in subsystem structure
    failures.append(Failure(
        message=(
            "Logical addressability (decoding/readout) typically presumes a subsystem structure "
            "(factorization or equivalent). Without it, 'where the code lives' is undefined."
        ),
        missing_assumptions=[hilbert_factorization]
    ))

    # 4) Recovery requires a notion of before/after and a noise interface
    failures.append(Failure(
        message=(
            "Recovery is a time-directed notion: it compares pre-noise and post-noise states "
            "and applies a decoder. Without a time parameter and a subsystem/noise interface, "
            "recovery is not even formulated."
        ),
        missing_assumptions=[preferred_time, hilbert_factorization]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T03 — Code Subspace Minimality Calibration\n")

    print("Concept inventory (names + required assumptions to even speak about them):\n")
    inventory = [code_subspace, encoding_map, logical_alphabet, logical_addressability, recovery_map]
    for c in inventory:
        print(f"- {c.name}")
        if c.requires:
            for req in c.requires:
                print(f"    requires: {req.name} [{req.category}]")
        else:
            print("    requires: (none)")
    print("")

    print("Minimality failure modes (calibration checklist):\n")
    failures = check_code_subspace_minimality()
    for f in failures:
        print(f"• {f.message}")
        if f.missing_assumptions:
            print("  Missing assumptions to even formulate:")
            for a in f.missing_assumptions:
                print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does NOT claim these assumptions hold fundamentally.")
    print("It only records what is typically required to make 'code subspace' a non-vacuous claim.\n")


if __name__ == "__main__":
    report()
