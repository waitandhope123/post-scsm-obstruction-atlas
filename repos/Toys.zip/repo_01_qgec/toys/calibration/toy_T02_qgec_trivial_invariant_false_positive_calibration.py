"""
T02 — QGEC Trivial Invariant False-Positive Calibration

Purpose:
Identify structures that can look like "protected information" (because they are
invariant or conserved) but do NOT implement error correction.

This toy draws NO conclusions about quantum gravity.
It only creates a clean filter: "invariant" is not the same as "error-corrected".

Operational criterion used here (minimal, not sufficient):
To count as QEC-like protection, an object must plausibly support:
  (1) nontrivial distinguishability among multiple logical states, AND
  (2) recoverability after a specified class of perturbations/erasures, AND
  (3) logical addressability (a notion of decoding / retrieval)

Anything failing these is a "false positive candidate".
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Minimal assumptions for discussing "retrieval" in any sense
# (These are deliberately weak; later toys will stress them.)
# ---------------------------------------------------------------------

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Total Hilbert space factorizes into stable subsystems.",
    category="locality"
)

external_environment = Assumption(
    name="external_environment",
    description="A separable environment exists to which perturbations/noise can be attributed.",
    category="observer"
)

preferred_time = Assumption(
    name="preferred_time",
    description="A global or preferred time parameter exists (for 'before/after' comparisons).",
    category="background"
)

# ---------------------------------------------------------------------
# False-positive candidates: invariants that may be mistaken for "memory"
# ---------------------------------------------------------------------

false_positive_candidates = [
    Concept(
        name="global_conserved_charge_label",
        requires=[]  # Conserved charges can be stated without much structure.
    ),
    Concept(
        name="total_hilbert_space_dimension_label",
        requires=[]
    ),
    Concept(
        name="superselection_sector_identifier",
        requires=[]
    ),
    Concept(
        name="global_topological_invariant_label",
        requires=[]
    ),
]


# ---------------------------------------------------------------------
# Minimal screening tests (not proofs)
# ---------------------------------------------------------------------

def screen_for_qec_like_properties(concept: Concept):
    """
    Returns:
        (passed: bool, failures: list[Failure])

    This is not a theorem engine.
    It's an explicit checklist preventing conceptual cheating.
    """
    failures = []

    # Test 1: distinguishability among multiple logical states
    # Many invariants give at most one bit-like label (sector label),
    # and often do not support a structured logical alphabet.
    failures.append(Failure(
        message=(
            "Fails minimal distinguishability test: "
            "invariants often label a sector but do not supply a nontrivial logical state space."
        ),
        missing_assumptions=[]
    ))

    # Test 2: recoverability after perturbation
    # Without a notion of subsystem erasure/noise and a decoding map,
    # 'recovery' is not even formulated.
    failures.append(Failure(
        message=(
            "Fails minimal recoverability test: "
            "no specified noise/erasure model and no recovery channel/decoder is defined."
        ),
        missing_assumptions=[hilbert_factorization, external_environment, preferred_time]
    ))

    # Test 3: logical addressability / decoding
    failures.append(Failure(
        message=(
            "Fails minimal addressability test: "
            "no decoding notion (who/what reads it, from which degrees of freedom) is specified."
        ),
        missing_assumptions=[hilbert_factorization]
    ))

    # In this calibration toy, we treat all listed candidates as failing by default,
    # because they are invariants absent a code structure.
    return False, failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report(concepts):
    print("\nQGEC T02 — Trivial Invariant False-Positive Calibration\n")
    print("Goal: Separate 'invariant' from 'QEC-like protected information'.\n")

    for c in concepts:
        print(f"Candidate: {c.name}")
        print("  Declared requirements to state it:")
        if c.requires:
            for req in c.requires:
                print(f"   - {req.name} [{req.category}]")
        else:
            print("   - (none)")

        passed, failures = screen_for_qec_like_properties(c)
        print(f"  QEC-like screening result: {'PASS' if passed else 'FAIL'}")

        for f in failures:
            print(f"   • {f.message}")
            if f.missing_assumptions:
                print("     Needs (to even formulate recovery/decoding):")
                for a in f.missing_assumptions:
                    print(f"       - {a.name} [{a.category}]")
        print("")

    print("Note: This toy does NOT claim these invariants are unphysical.")
    print("It claims only that invariance alone does not constitute error correction.\n")


if __name__ == "__main__":
    report(false_positive_candidates)
