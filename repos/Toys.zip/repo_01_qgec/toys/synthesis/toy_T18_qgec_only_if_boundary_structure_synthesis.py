"""
T18 — QGEC "Only If Boundary / Anchor Structure" (Synthesis)

Purpose:
Record a second conditional necessity:

QEC-like protected information is ONLY POSSIBLE IF
there exists some invariant anchoring structure capable of supporting
stable subregions, operator identification, and recovery.

In known constructions, this role is played by fixed boundary or
asymptotic structure (e.g. AdS boundary).

This toy:
- does NOT claim boundaries are fundamental
- does NOT claim no alternatives could exist
- records what is currently required by known QEC-supporting frameworks
"""

from repo_01_qgec.qgec_foundations import Assumption

# ---------------------------------------------------------------------
# Anchor structure under examination
# ---------------------------------------------------------------------

boundary_or_anchor_structure = Assumption(
    name="boundary_or_equivalent_anchor_structure",
    description=(
        "Some invariant anchoring structure exists (e.g., asymptotic boundary, "
        "global reference structure, or equivalent) that stabilizes subregions, "
        "operator identification, and recovery notions."
    ),
    category="boundary"
)

# ---------------------------------------------------------------------
# Evidence summary (from baselines and stress tests)
# ---------------------------------------------------------------------

evidence_points = [
    "Holographic QEC (T08) succeeds only with fixed boundary structure.",
    "Removing boundary structure (T09) collapses entanglement wedge reconstruction.",
    "Full diffeomorphism invariance (T13) removes local anchoring absent boundaries.",
    "Gauge constraints (T15) destabilize operator identity without anchoring."
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T18 — 'Only If Boundary / Anchor Structure' (Synthesis)\n")

    print("Claim:\n")
    print(
        "QEC-like protected information is ONLY POSSIBLE IF\n"
        "there exists some invariant anchoring structure capable of\n"
        "supporting stable subregions and operator identification.\n"
    )

    print("Anchor requirement:\n")
    print(f"- {boundary_or_anchor_structure.name} [{boundary_or_anchor_structure.category}]")
    print(f"  {boundary_or_anchor_structure.description}\n")

    print("Supporting evidence (from earlier toys):\n")
    for p in evidence_points:
        print(f"- {p}")
    print("")

    print("Clarifications:\n")
    print("- This does NOT assert that asymptotic boundaries are fundamental.")
    print("- It allows for unknown alternative anchoring mechanisms.")
    print("- It records that, to date, no boundary-free construction has met the requirements.\n")

    print("Status:\n")
    print("This is a CONDITIONAL necessity statement, not a no-go theorem.\n")


if __name__ == "__main__":
    report()
