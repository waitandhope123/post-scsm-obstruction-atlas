"""
T19 — QGEC Hard vs Soft Obstruction Map (Synthesis)

Purpose:
Consolidate obstruction mechanisms discovered across calibration/baseline/stress
into a map classified as:

- HARD obstruction: not formulable under required invariance/constraints
- SOFT obstruction: formulable in principle but no known construction survives (yet)

This toy:
- introduces no new physics
- does not claim completeness
- produces an explicit atlas-like list used by T20
"""

from repo_01_qgec.qgec_foundations import Failure

# ---------------------------------------------------------------------
# Obstruction entries (synthetic ledger distilled from T11–T15 + earlier)
# ---------------------------------------------------------------------

hard_obstructions = [
    Failure(
        message="Without subsystem/equivalent structure, 'local noise', 'error set E', and 'recovery' are not formulable (T07, T12).",
        missing_assumptions=[]
    ),
    Failure(
        message="Under full diffeomorphism invariance, coordinate-local support and region-based factorization are not physical primitives (T13).",
        missing_assumptions=[]
    ),
    Failure(
        message="Gauge constraints spoil clean operator/subsystem notions; logical operator identity becomes gauge-relative without invariant dressing/anchoring (T15).",
        missing_assumptions=[]
    ),
    Failure(
        message="Without a definable noise interface, the core QEC claim 'this code corrects this noise' collapses as a statement (T12).",
        missing_assumptions=[]
    ),
]

soft_obstructions = [
    Failure(
        message="Dynamical geometry threatens stable identification of code subspace and operator support; instability may be generic but not proven universal (T11, T14).",
        missing_assumptions=[]
    ),
    Failure(
        message="Boundary-free, fully invariant anchoring mechanisms are currently unknown; boundary structure is the only established anchor in known success cases (T08–T09, T18).",
        missing_assumptions=[]
    ),
    Failure(
        message="Relational repairs (matter clocks/rods, reference fields) might reintroduce effective subsystem structure but may be non-fundamental; not evaluated here (deferred).",
        missing_assumptions=[]
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T19 — Hard vs Soft Obstruction Map (Synthesis)\n")

    print("HARD obstructions (definitional / principle-level):\n")
    for i, f in enumerate(hard_obstructions, start=1):
        print(f"{i}. {f.message}")
    print("")

    print("SOFT obstructions (no surviving construction known; could admit reformulation):\n")
    for i, f in enumerate(soft_obstructions, start=1):
        print(f"{i}. {f.message}")
    print("")

    print("Interpretation rule:")
    print("- HARD obstructions block QEC-like protected information unless assumptions are reintroduced.")
    print("- SOFT obstructions indicate open design space but no established solution under repo constraints.\n")


if __name__ == "__main__":
    report()
