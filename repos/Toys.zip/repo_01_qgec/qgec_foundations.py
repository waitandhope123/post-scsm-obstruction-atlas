"""
qgec_foundations.py

Foundational scaffolding for the Quantum Gravity Error Correction (QGEC)
constraint-mapping repository.

This file defines ONLY:
- how assumptions are declared
- how concepts are named
- how failures are recorded

It deliberately contains:
- no physics
- no models
- no equations
- no conclusions

All executable toys in this repository MUST import from this file.
"""

# ---------------------------------------------------------------------
# Assumption tracking
# ---------------------------------------------------------------------

class Assumption:
    """
    Represents an explicit structural assumption required by a toy.

    Parameters:
        name (str): Short identifier for the assumption.
        description (str): Precise description of what is being assumed.
        category (str): One of:
            - 'background'
            - 'locality'
            - 'gauge'
            - 'semiclassical'
            - 'observer'
            - 'boundary'
    """
    def __init__(self, name, description, category):
        self.name = name
        self.description = description
        self.category = category


# ---------------------------------------------------------------------
# Concept declaration
# ---------------------------------------------------------------------

class Concept:
    """
    Represents a named conceptual structure (e.g. noise, code subspace).

    This class does NOT define the concept.
    It only records which assumptions are required to even speak about it.
    """
    def __init__(self, name, requires=None):
        self.name = name
        self.requires = requires or []


# ---------------------------------------------------------------------
# Failure reporting
# ---------------------------------------------------------------------

class Failure:
    """
    Represents a clean, declarative failure.

    Failures should explain:
    - what collapsed
    - why it collapsed
    - which assumptions were missing or violated
    """
    def __init__(self, message, missing_assumptions=None):
        self.message = message
        self.missing_assumptions = missing_assumptions or []
