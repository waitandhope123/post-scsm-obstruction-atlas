"""
persistence_foundations.py

Shared foundational definitions for Repo 2:
Background-Free Protected Information / Persistence Analysis.

This module provides lightweight bookkeeping classes used by all toys
in Repo 2. These classes do NOT encode physics; they encode dependencies,
assumptions, and failure modes.

Design principles:
- No dynamics
- No simulation
- No ontology
- Purely structural / conceptual bookkeeping
"""

from dataclasses import dataclass
from typing import List, Optional


# ---------------------------------------------------------------------
# Core bookkeeping primitives
# ---------------------------------------------------------------------

@dataclass(frozen=True)
class Assumption:
    """
    Represents a structural assumption required to even formulate
    a concept or claim.

    Examples:
    - preferred_time
    - reference_frame
    - gauge_fixing
    """
    name: str
    description: str
    category: str  # e.g. 'background', 'observer', 'gauge', 'relational'


@dataclass(frozen=True)
class Concept:
    """
    Represents a conceptual object (e.g. 'persistent information',
    'identity', 'memory', 'retrievability') together with the assumptions
    required to define it.

    This class does NOT assert existence or physicality.
    """
    name: str
    requires: Optional[List[Assumption]] = None


@dataclass(frozen=True)
class Failure:
    """
    Represents a recorded obstruction or collapse:
    a point where a concept becomes undefined, unstable, or gauge-relative
    once certain assumptions are removed or enforced.

    This is a first-class outcome.
    """
    message: str
    missing_assumptions: Optional[List[Assumption]] = None


# ---------------------------------------------------------------------
# Utility helpers (optional, minimal)
# ---------------------------------------------------------------------

def list_assumptions(assumptions: List[Assumption]) -> None:
    """
    Pretty-print a list of assumptions.
    """
    for a in assumptions:
        print(f"- {a.name} [{a.category}]: {a.description}")


def list_concept_requirements(concept: Concept) -> None:
    """
    Pretty-print the requirements of a concept.
    """
    print(f"Concept: {concept.name}")
    if not concept.requires:
        print("  requires: (none)")
    else:
        for a in concept.requires:
            print(f"  requires: {a.name} [{a.category}]")
