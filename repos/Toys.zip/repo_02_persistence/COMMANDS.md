## Repo 2 — Background-Free Persistence

### Calibration
```bash
python -m repo_02_persistence.toys.calibration.toy_T01_persistence_definition_calibration
python -m repo_02_persistence.toys.calibration.toy_T02_persistence_trivial_invariant_false_positive_calibration
python -m repo_02_persistence.toys.calibration.toy_T03_persistence_identity_vs_retrievability_calibration
python -m repo_02_persistence.toys.calibration.toy_T04_persistence_gauge_averaging_effect_calibration
python -m repo_02_persistence.toys.calibration.toy_T05_persistence_assumption_registry_calibration
```

### Baseline
```bash
python -m repo_02_persistence.toys.baseline.toy_T06_persistence_fixed_time_reference_baseline
python -m repo_02_persistence.toys.baseline.toy_T07_persistence_external_memory_register_baseline
python -m repo_02_persistence.toys.baseline.toy_T08_persistence_relational_clock_construction_baseline
python -m repo_02_persistence.toys.baseline.toy_T09_persistence_semiclassical_observer_dependence_baseline
python -m repo_02_persistence.toys.baseline.toy_T10_persistence_effective_only_baseline
```

### Stress Tests
```bash
python -m repo_02_persistence.toys.stress.toy_T11_persistence_remove_fixed_time_stress
python -m repo_02_persistence.toys.stress.toy_T12_persistence_remove_reference_frames_stress
python -m repo_02_persistence.toys.stress.toy_T13_persistence_enforce_full_gauge_invariance_stress
python -m repo_02_persistence.toys.stress.toy_T14_persistence_dynamic_geometry_information_loss_stress
python -m repo_02_persistence.toys.stress.toy_T15_persistence_identity_indistinguishability_stress
```

### Synthesis
```bash
python -m repo_02_persistence.toys.synthesis.toy_T16_persistence_minimal_requirement_set_synthesis
python -m repo_02_persistence.toys.synthesis.toy_T17_persistence_only_if_reference_structure_synthesis
python -m repo_02_persistence.toys.synthesis.toy_T18_persistence_only_if_semiclassical_limit_synthesis
python -m repo_02_persistence.toys.synthesis.toy_T19_persistence_hard_vs_soft_obstruction_map_synthesis
python -m repo_02_persistence.toys.synthesis.toy_T20_persistence_final_scope_limited_conclusion_synthesis
```
