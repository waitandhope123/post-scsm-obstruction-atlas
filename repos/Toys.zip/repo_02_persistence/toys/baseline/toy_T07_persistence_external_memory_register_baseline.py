"""
T07 — Persistence via External Memory Register (Baseline)

Purpose:
Demonstrate that persistence is well-defined when information
is stored in an external memory register that is stable and accessible.

This establishes a baseline where persistence is outsourced
to an explicit external structure.
"""

from repo_02_persistence.persistence_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Baseline assumptions explicitly in force
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="A global or preferred time parameter exists.",
    category="background"
)

external_memory_register = Assumption(
    name="external_memory_register",
    description="A stable external memory/register exists to store information.",
    category="observer"
)

external_observer = Assumption(
    name="external_observer",
    description="An observer exists to write to and read from the register.",
    category="observer"
)

retrieval_operation = Assumption(
    name="retrieval_operation",
    description="A retrieval/readout operation exists.",
    category="observer"
)

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="A stable notion of distinguishability exists.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Persistence concept enabled by baseline
# ---------------------------------------------------------------------

externalized_persistence = Concept(
    name="external_memory_persistence",
    requires=[
        preferred_time,
        external_memory_register,
        external_observer,
        retrieval_operation,
        stable_state_distinguishability
    ]
)

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T07 External Memory Register Baseline\n")

    print("Baseline assumptions explicitly in force:\n")
    for a in externalized_persistence.requires:
        print(f" - {a.name} [{a.category}]: {a.description}")

    print("\nPersistence status:")
    print(
        "Persistence is well-defined when information is stored in a stable "
        "external register that can be written to and read from over time."
    )

    print("\nInterpretation:")
    print(
        "This baseline demonstrates that persistence can be made robust\n"
        "by outsourcing it to external memory structures.\n"
        "No claim is made that such structures are fundamental."
    )


if __name__ == "__main__":
    report()
