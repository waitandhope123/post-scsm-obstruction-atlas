"""
T11 — Remove Fixed Time (Stress Test)

Purpose:
Examine what happens to persistence notions
when no preferred or effective time parameter exists.

This toy removes:
- global time
- effective semiclassical time
- explicit before/after ordering

and records which persistence claims collapse.
"""

from repo_02_persistence.persistence_foundations import Assumption, Failure

# ---------------------------------------------------------------------
# Retained assumptions (explicitly)
# ---------------------------------------------------------------------

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="A stable notion of distinguishability exists.",
    category="gauge"
)

external_observer = Assumption(
    name="external_observer",
    description="An observer exists.",
    category="observer"
)

retrieval_operation = Assumption(
    name="retrieval_operation",
    description="A retrieval or comparison operation exists.",
    category="observer"
)

# ---------------------------------------------------------------------
# Removed assumption
# ---------------------------------------------------------------------

removed_time = Assumption(
    name="preferred_time",
    description="No preferred or effective time parameter exists.",
    category="background"
)

# ---------------------------------------------------------------------
# Stress analysis
# ---------------------------------------------------------------------

failures = [
    Failure(
        message=(
            "Without any time or ordering parameter, persistence cannot be "
            "defined as 'something lasting' or 'remaining the same'."
        ),
        missing_assumptions=[removed_time]
    ),
    Failure(
        message=(
            "Retrieval and comparison operations require a notion of 'before' "
            "and 'after'; without ordering, retrieval is ill-defined."
        ),
        missing_assumptions=[removed_time]
    ),
    Failure(
        message=(
            "State distinguishability alone does not provide persistence "
            "without temporal context."
        ),
        missing_assumptions=[]
    )
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T11 Remove Fixed Time (Stress Test)\n")

    print("Removed assumption:")
    print(f" - {removed_time.name} [{removed_time.category}]\n")

    print("Stress-test failures triggered:\n")
    for f in failures:
        print(f" • {f.message}")
        if f.missing_assumptions:
            print("   Missing:")
            for a in f.missing_assumptions:
                print(f"    - {a.name} [{a.category}]")
        print("")

    print("Conclusion:")
    print(
        "Without any notion of time or ordering, persistence collapses\n"
        "as a definable concept."
    )


if __name__ == "__main__":
    report()
