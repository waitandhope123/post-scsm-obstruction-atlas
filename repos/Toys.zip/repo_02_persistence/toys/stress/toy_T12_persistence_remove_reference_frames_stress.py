"""
T12 — Remove Reference Frames / Observers (Stress Test)

Purpose:
Examine what happens to persistence notions
when no observer, reference frame, or retrieval agent exists.

This toy removes:
- external observers
- reference frames
- retrieval/comparison interfaces

and records which persistence claims collapse.
"""

from repo_02_persistence.persistence_foundations import Assumption, Failure

# ---------------------------------------------------------------------
# Retained assumptions (explicitly)
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="A notion of time or ordering exists.",
    category="background"
)

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="A stable notion of distinguishability exists.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Removed assumptions
# ---------------------------------------------------------------------

removed_observer = Assumption(
    name="external_observer",
    description="No observer or reference frame exists.",
    category="observer"
)

removed_retrieval = Assumption(
    name="retrieval_operation",
    description="No retrieval or comparison operation exists.",
    category="observer"
)

# ---------------------------------------------------------------------
# Stress analysis
# ---------------------------------------------------------------------

failures = [
    Failure(
        message=(
            "Without an observer or reference frame, there is no entity "
            "to establish or recognize persistence relations."
        ),
        missing_assumptions=[removed_observer]
    ),
    Failure(
        message=(
            "Persistence as information requires some notion of retrieval "
            "or comparison; without it, persistence collapses into "
            "uninterpreted existence."
        ),
        missing_assumptions=[removed_retrieval]
    ),
    Failure(
        message=(
            "State distinguishability alone does not guarantee persistence "
            "without a comparison or access mechanism."
        ),
        missing_assumptions=[]
    )
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T12 Remove Reference Frames / Observers (Stress Test)\n")

    print("Removed assumptions:")
    print(f" - {removed_observer.name} [{removed_observer.category}]")
    print(f" - {removed_retrieval.name} [{removed_retrieval.category}]\n")

    print("Stress-test failures triggered:\n")
    for f in failures:
        print(f" • {f.message}")
        if f.missing_assumptions:
            print("   Missing:")
            for a in f.missing_assumptions:
                print(f"    - {a.name} [{a.category}]")
        print("")

    print("Conclusion:")
    print(
        "Without observers, reference frames, or retrieval interfaces,\n"
        "persistence-as-information is not definable."
    )


if __name__ == "__main__":
    report()
