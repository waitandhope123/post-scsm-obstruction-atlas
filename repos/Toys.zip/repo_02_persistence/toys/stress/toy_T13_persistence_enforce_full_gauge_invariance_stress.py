"""
T13 — Enforce Full Gauge Invariance (Stress Test)

Purpose:
Examine whether persistence can survive
when only fully gauge-invariant quantities
are admitted as physical.

This toy enforces:
- full gauge invariance
- no gauge fixing
- no reference structures

and records what happens to persistence.
"""

from repo_02_persistence.persistence_foundations import Assumption, Failure

# ---------------------------------------------------------------------
# Enforced constraint
# ---------------------------------------------------------------------

full_gauge_invariance = Assumption(
    name="full_gauge_invariance",
    description="Only fully gauge-invariant quantities are physical.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Removed / destabilized structures
# ---------------------------------------------------------------------

removed_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="Gauge averaging collapses distinguishability.",
    category="gauge"
)

removed_identity_tracking = Assumption(
    name="state_identity_tracking",
    description="No gauge-invariant notion of tracking identity across configurations.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Stress analysis
# ---------------------------------------------------------------------

failures = [
    Failure(
        message=(
            "Under full gauge invariance, states related by gauge "
            "transformations are identified; distinctions required "
            "for persistence are erased."
        ),
        missing_assumptions=[removed_distinguishability]
    ),
    Failure(
        message=(
            "Persistence requires tracking 'the same state' across "
            "configurations or times; no fully gauge-invariant notion "
            "of state identity generally exists."
        ),
        missing_assumptions=[removed_identity_tracking]
    ),
    Failure(
        message=(
            "Gauge-invariant quantities typically label entire equivalence "
            "classes rather than supporting nontrivial memory."
        ),
        missing_assumptions=[]
    )
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T13 Enforce Full Gauge Invariance (Stress Test)\n")

    print("Enforced constraint:")
    print(f" - {full_gauge_invariance.name} [{full_gauge_invariance.category}]\n")

    print("Stress-test failures triggered:\n")
    for f in failures:
        print(f" • {f.message}")
        if f.missing_assumptions:
            print("   Undermines:")
            for a in f.missing_assumptions:
                print(f"    - {a.name} [{a.category}]")
        print("")

    print("Conclusion:")
    print(
        "Enforcing full gauge invariance collapses distinguishability\n"
        "and identity tracking, destroying persistence-as-information."
    )


if __name__ == "__main__":
    report()
