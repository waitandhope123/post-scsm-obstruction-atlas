"""
T02 — Persistence Trivial Invariant False-Positive Calibration

Purpose:
Demonstrate that invariance alone does NOT constitute
nontrivial persistent information.

This toy:
- examines invariant quantities often mistaken for 'memory'
- applies minimal persistence screening tests
- records why these candidates fail without adding structure
"""

from repo_02_persistence.persistence_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Minimal persistence screening criteria (informal but strict)
# ---------------------------------------------------------------------
# A nontrivial notion of persistence must support:
# 1. Distinguishability between multiple possible states
# 2. Some notion of retrieval or comparison (even abstract)
# 3. Non-vacuous informational content (not a single fixed label)

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="A stable notion of distinguishability exists.",
    category="gauge"
)

retrieval_operation = Assumption(
    name="retrieval_operation",
    description="Some retrieval or comparison operation is definable.",
    category="observer"
)

# ---------------------------------------------------------------------
# Candidate invariant quantities often misidentified as persistence
# ---------------------------------------------------------------------

candidates = [
    Concept(
        name="global_conserved_charge_label",
        requires=[]
    ),
    Concept(
        name="superselection_sector_identifier",
        requires=[]
    ),
    Concept(
        name="topological_sector_label",
        requires=[]
    ),
    Concept(
        name="dimension_of_hilbert_space",
        requires=[]
    ),
    Concept(
        name="bare_existence_of_state",
        requires=[]
    ),
]

# ---------------------------------------------------------------------
# Failure analysis
# ---------------------------------------------------------------------

def analyze(candidate: Concept):
    failures = []

    failures.append(Failure(
        message=(
            "Fails nontrivial distinguishability: invariant labels typically "
            "identify a single sector, not multiple informational states."
        ),
        missing_assumptions=[stable_state_distinguishability]
    ))

    failures.append(Failure(
        message=(
            "Fails retrievability/comparison: no notion of accessing, comparing, "
            "or reading out information is specified."
        ),
        missing_assumptions=[retrieval_operation]
    ))

    failures.append(Failure(
        message=(
            "Fails informational non-vacuity: persistence requires more than "
            "the mere continued existence of something."
        ),
        missing_assumptions=[]
    ))

    return failures

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T02 Trivial Invariant False-Positive Calibration\n")
    print("Goal: Separate 'invariant existence' from 'nontrivial persistent information'.\n")

    for c in candidates:
        print(f"Candidate: {c.name}")
        print("  Declared requirements: (none)")
        print("  Persistence screening result: FAIL")

        failures = analyze(c)
        for f in failures:
            print(f"   • {f.message}")
            if f.missing_assumptions:
                print("     Would require:")
                for a in f.missing_assumptions:
                    print(f"       - {a.name} [{a.category}]")
        print("")

    print("Note:")
    print(
        "This toy does NOT claim invariant quantities are unphysical.\n"
        "It claims that invariance alone does not constitute persistence or memory.\n"
    )


if __name__ == "__main__":
    report()
