"""
T04 — Persistence Gauge Averaging Effect Calibration

Purpose:
Demonstrate that enforcing full gauge invariance via averaging
generically collapses distinguishability and destroys persistence.

This toy isolates the tension between:
- gauge invariance
- stable, retrievable information
"""

from repo_02_persistence.persistence_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="A stable notion of state distinguishability exists.",
    category="gauge"
)

retrieval_operation = Assumption(
    name="retrieval_operation",
    description="Some retrieval or comparison operation exists.",
    category="observer"
)

full_gauge_invariance = Assumption(
    name="full_gauge_invariance",
    description="Only fully gauge-invariant quantities are physical.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Concept under stress
# ---------------------------------------------------------------------

gauge_averaged_persistence = Concept(
    name="gauge_averaged_persistence",
    requires=[
        full_gauge_invariance
    ]
)

# ---------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------

def analyze_gauge_averaging():
    failures = []

    failures.append(Failure(
        message=(
            "Gauge averaging typically identifies or mixes states "
            "that were previously distinguishable, collapsing "
            "informational distinctions."
        ),
        missing_assumptions=[stable_state_distinguishability]
    ))

    failures.append(Failure(
        message=(
            "After gauge averaging, no stable retrieval or comparison "
            "operation can distinguish prior logical states."
        ),
        missing_assumptions=[retrieval_operation]
    ))

    failures.append(Failure(
        message=(
            "Persistence collapses to a single invariant equivalence class, "
            "removing nontrivial informational content."
        ),
        missing_assumptions=[]
    ))

    return failures

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T04 Gauge Averaging Effect Calibration\n")

    print("Concept: gauge_averaged_persistence")
    print("  Requires:")
    for a in gauge_averaged_persistence.requires:
        print(f"   - {a.name} [{a.category}]")

    print("\nStress-test result: FAIL")
    failures = analyze_gauge_averaging()
    for f in failures:
        print(f" • {f.message}")
        if f.missing_assumptions:
            print("   Undermines:")
            for a in f.missing_assumptions:
                print(f"    - {a.name} [{a.category}]")

    print("\nConclusion:")
    print(
        "Gauge averaging enforces invariance by erasing distinctions.\n"
        "This destroys the very structure required for persistence-as-information.\n"
    )


if __name__ == "__main__":
    report()
