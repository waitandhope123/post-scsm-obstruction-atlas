"""
T05 — Persistence Assumption Registry Calibration

Purpose:
Construct an explicit taxonomy of assumptions that persistence-like claims
commonly rely on, so later baseline/stress phases can remove them cleanly.

This toy:
- makes no claims about fundamentality
- records only what is required to even state persistence definitions
"""

from repo_02_persistence.persistence_foundations import Assumption

# ---------------------------------------------------------------------
# Assumption registry
# ---------------------------------------------------------------------

assumptions = [
    # Background / time
    Assumption(
        name="preferred_time",
        description="A global or preferred time parameter exists.",
        category="background"
    ),
    Assumption(
        name="temporal_ordering",
        description="A before/after ordering exists (even if not global time).",
        category="background"
    ),
    Assumption(
        name="fixed_reference_frame",
        description="A fixed coordinate/reference frame exists.",
        category="background"
    ),

    # Observer / operational
    Assumption(
        name="external_observer",
        description="An observer exists who can compare states across time/orderings.",
        category="observer"
    ),
    Assumption(
        name="retrieval_operation",
        description="A retrieval/comparison/readout operation is definable.",
        category="observer"
    ),
    Assumption(
        name="operational_access",
        description="There is an operational procedure to distinguish outcomes.",
        category="observer"
    ),

    # Gauge / invariance
    Assumption(
        name="stable_state_distinguishability",
        description="A stable notion of distinguishability/inner product exists.",
        category="gauge"
    ),
    Assumption(
        name="full_gauge_invariance",
        description="Only fully gauge-invariant quantities are physical.",
        category="gauge"
    ),
    Assumption(
        name="gauge_fixing_or_reference_choice",
        description="Gauge redundancy is partially fixed or a reference choice is made.",
        category="gauge"
    ),

    # Relational scaffolding
    Assumption(
        name="relational_clock",
        description="A relational clock variable exists to define persistence relationally.",
        category="relational"
    ),
    Assumption(
        name="reference_fields_rods_clocks",
        description="Matter/reference fields exist to define relational positions or times.",
        category="relational"
    ),
    Assumption(
        name="semiclassical_limit",
        description="A semiclassical regime exists where approximate background notions emerge.",
        category="semiclassical"
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T05 Persistence Assumption Registry Calibration\n")

    by_cat = {}
    for a in assumptions:
        by_cat.setdefault(a.category, []).append(a)

    for cat in sorted(by_cat.keys()):
        print(f"Category: {cat}")
        for a in by_cat[cat]:
            print(f" - {a.name}: {a.description}")
        print("")

    print(f"Total assumptions recorded: {len(assumptions)}\n")

    print("Note:")
    print(
        "No assumption is claimed fundamental or non-fundamental here.\n"
        "This registry exists solely to support later assumption removal and synthesis.\n"
    )


if __name__ == "__main__":
    report()
