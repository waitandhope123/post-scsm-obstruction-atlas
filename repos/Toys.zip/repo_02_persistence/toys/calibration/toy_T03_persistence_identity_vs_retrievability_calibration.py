"""
T03 — Persistence: Identity vs Retrievability Calibration

Purpose:
Disentangle two commonly conflated notions:
- persistence as 'identity over time'
- persistence as retrievable / comparable information

This toy demonstrates that identity without retrievability
collapses into trivial existence and does not support memory-like persistence.
"""

from repo_02_persistence.persistence_foundations import Assumption, Concept, Failure

# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="A notion of before/after or temporal ordering exists.",
    category="background"
)

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="A stable notion of distinguishability exists.",
    category="gauge"
)

retrieval_operation = Assumption(
    name="retrieval_operation",
    description="Some retrieval or comparison operation is definable.",
    category="observer"
)

external_observer = Assumption(
    name="external_observer",
    description="An observer or reference exists to perform comparison.",
    category="observer"
)

# ---------------------------------------------------------------------
# Concepts under comparison
# ---------------------------------------------------------------------

identity_based_persistence = Concept(
    name="identity_based_persistence",
    requires=[
        preferred_time
    ]
)

retrievable_persistence = Concept(
    name="retrievable_persistence",
    requires=[
        preferred_time,
        stable_state_distinguishability,
        retrieval_operation,
        external_observer
    ]
)

# ---------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------

def analyze_identity_only():
    failures = []

    failures.append(Failure(
        message=(
            "Identity alone does not provide informational persistence: "
            "there is no way to distinguish or compare states across time."
        ),
        missing_assumptions=[stable_state_distinguishability]
    ))

    failures.append(Failure(
        message=(
            "Without retrieval or comparison, identity collapses into "
            "bare continued existence."
        ),
        missing_assumptions=[retrieval_operation, external_observer]
    ))

    return failures


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T03 Identity vs Retrievability Calibration\n")

    print("Concept: identity_based_persistence")
    print("  Requires:")
    for a in identity_based_persistence.requires:
        print(f"   - {a.name} [{a.category}]")

    print("\nResult: INSUFFICIENT for nontrivial persistence.")
    failures = analyze_identity_only()
    for f in failures:
        print(f" • {f.message}")
        if f.missing_assumptions:
            print("   Missing:")
            for a in f.missing_assumptions:
                print(f"    - {a.name} [{a.category}]")

    print("\nConcept: retrievable_persistence")
    print("  Requires:")
    for a in retrievable_persistence.requires:
        print(f"   - {a.name} [{a.category}]")

    print("\nResult: SUFFICIENT (definitionally) for nontrivial persistence.")
    print(
        "Note: This does NOT assert fundamentality.\n"
        "It records that persistence-as-information requires retrievability."
    )


if __name__ == "__main__":
    report()
