"""
toy_T05_semiclassical_assumption_taxonomy_calibration.py

Repo 6 — T05 Semiclassical vs Fundamental Assumption Taxonomy Calibration

Purpose:
Enumerate all assumptions used across Repo 6 calibration toys
to make later removals and stress tests explicit.
"""

def main():
    print("\nRepo 6 — T05 Semiclassical vs Fundamental Assumption Taxonomy Calibration\n")

    taxonomy = {
        "background": [
            "preferred_time",
            "effective_background",
        ],
        "gauge": [
            "full_gauge_invariance",
            "stable_inner_product",
            "stable_distinguishability",
        ],
        "observer": [
            "observer_access",
            "operational_measurement",
            "coarse_graining",
        ],
        "relational": [
            "relational_time",
            "stable_information_carrier",
        ],
        "semiclassical": [
            "semiclassical_limit",
        ],
    }

    total = 0
    for category, assumptions in taxonomy.items():
        print(f"Category: {category}")
        for a in assumptions:
            print(f" - {a}")
            total += 1
        print()

    print(f"Total assumptions recorded: {total}\n")

    print(
        "Note:\n"
        "No assumption is claimed fundamental or non-fundamental here.\n"
        "This taxonomy exists solely to support explicit assumption\n"
        "removal in later baseline and stress-test toys."
    )


if __name__ == "__main__":
    main()
