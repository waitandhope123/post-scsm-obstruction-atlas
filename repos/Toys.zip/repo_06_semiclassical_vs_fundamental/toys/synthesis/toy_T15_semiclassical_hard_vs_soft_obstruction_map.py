"""
toy_T15_semiclassical_hard_vs_soft_obstruction_map.py

Repo 6 — T15 Hard vs Soft Obstruction Map (Synthesis)

Purpose:
Classify which failures separating semiclassical and fundamental
physics are principle-level (HARD) versus open but unresolved (SOFT).
"""

def main():
    print("\nRepo 6 — T15 Hard vs Soft Obstruction Map (Synthesis)\n")

    print("HARD obstructions (principle-level):\n")

    print("1. No information without distinguishability")
    print("   • Enforcing full gauge invariance identifies states.")
    print("   • Distinct informational states collapse into equivalence classes.")
    print("   • Appears in: T02, T13, T14\n")

    print("2. No records without stable carriers")
    print("   • Records require stable, identifiable carriers.")
    print("   • Dynamical, background-free physics destabilizes all carriers.")
    print("   • Appears in: T04, T11–T14\n")

    print("3. No history without time or ordering")
    print("   • Histories require an ordering notion.")
    print("   • Removing time collapses trajectories into static relations.")
    print("   • Appears in: T03, T12, T14\n")

    print("4. No narrative without semiclassical structure")
    print("   • Narratives require persistent identity and causal ordering.")
    print("   • These rely on semiclassical suppression of fluctuations.")
    print("   • Appears in: T09–T14\n")

    print("SOFT obstructions (logically open, but no known realization):\n")

    print("1. Unknown non-semiclassical stabilizing mechanisms")
    print("   • Could there exist invariant structures that stabilize records")
    print("     without semiclassical physics?")
    print("   • No known example exists.\n")

    print("2. Unknown gauge-invariant notion of distinguishability")
    print("   • All known distinguishability relies on inner products")
    print("     or measurement structure.")
    print("   • A fully invariant alternative is not exhibited.\n")

    print("Interpretation rule:\n")
    print(
        "HARD obstructions block formulation in principle.\n"
        "SOFT obstructions mark logical possibility without construction.\n\n"
        "Repo 6 identifies the semiclassical/fundamental divide as\n"
        "a PRINCIPLE-LEVEL boundary, not merely a technical one."
    )


if __name__ == "__main__":
    main()
