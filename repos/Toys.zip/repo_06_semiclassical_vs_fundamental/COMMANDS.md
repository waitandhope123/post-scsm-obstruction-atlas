## Repo 6 — Semiclassical vs Fundamental

### Calibration
```bash
python -m repo_06_semiclassical_vs_fundamental.toys.calibration.toy_T01_semiclassical_definition_calibration
python -m repo_06_semiclassical_vs_fundamental.toys.calibration.toy_T02_effective_vs_fundamental_distinguishability_calibration
python -m repo_06_semiclassical_vs_fundamental.toys.calibration.toy_T03_semiclassical_vs_fundamental_dynamics_calibration
python -m repo_06_semiclassical_vs_fundamental.toys.calibration.toy_T04_semiclassical_vs_fundamental_records_calibration
python -m repo_06_semiclassical_vs_fundamental.toys.calibration.toy_T05_semiclassical_assumption_taxonomy_calibration
```

### Baseline
```bash
python -m repo_06_semiclassical_vs_fundamental.toys.baseline.toy_T06_semiclassical_regime_baseline
python -m repo_06_semiclassical_vs_fundamental.toys.baseline.toy_T07_observer_relative_effective_regime_baseline
python -m repo_06_semiclassical_vs_fundamental.toys.baseline.toy_T08_semiclassical_record_stability_baseline
python -m repo_06_semiclassical_vs_fundamental.toys.baseline.toy_T09_emergent_classical_narrative_baseline
python -m repo_06_semiclassical_vs_fundamental.toys.baseline.toy_T10_semiclassical_effective_only_baseline
```

### Stress Tests
```bash
python -m repo_06_semiclassical_vs_fundamental.toys.stress.toy_T11_remove_semiclassical_limit_stress
python -m repo_06_semiclassical_vs_fundamental.toys.stress.toy_T12_remove_effective_background_stress
python -m repo_06_semiclassical_vs_fundamental.toys.stress.toy_T13_enforce_full_gauge_invariance_stress
python -m repo_06_semiclassical_vs_fundamental.toys.stress.toy_T14_combined_fundamental_stress
```

### Synthesis
```bash
python -m repo_06_semiclassical_vs_fundamental.toys.synthesis.toy_T15_semiclassical_hard_vs_soft_obstruction_map
python -m repo_06_semiclassical_vs_fundamental.toys.synthesis.toy_T16_semiclassical_minimal_requirement_set_synthesis
python -m repo_06_semiclassical_vs_fundamental.toys.synthesis.toy_T17_semiclassical_only_if_effective_structure_synthesis
python -m repo_06_semiclassical_vs_fundamental.toys.synthesis.toy_T18_semiclassical_feasibility_boundary_synthesis
python -m repo_06_semiclassical_vs_fundamental.toys.synthesis.toy_T19_semiclassical_obstruction_summary_synthesis
python -m repo_06_semiclassical_vs_fundamental.toys.synthesis.toy_T20_final_repo_closure
```
