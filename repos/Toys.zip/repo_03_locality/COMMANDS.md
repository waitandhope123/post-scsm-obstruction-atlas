## Repo 3 — Diffeomorphism-Invariant Locality

### Calibration
```bash
python -m repo_03_locality.toys.calibration.toy_T01_locality_definition_calibration
python -m repo_03_locality.toys.calibration.toy_T02_locality_coordinate_dependence_calibration
python -m repo_03_locality.toys.calibration.toy_T03_locality_distance_vs_relation_calibration
python -m repo_03_locality.toys.calibration.toy_T04_locality_boundary_concept_dependency_calibration
python -m repo_03_locality.toys.calibration.toy_T05_locality_assumption_taxonomy_calibration
```

### Baseline
```bash
python -m repo_03_locality.toys.baseline.toy_T06_locality_fixed_background_neighborhoods_baseline
python -m repo_03_locality.toys.baseline.toy_T07_locality_quasi_local_construction_baseline
python -m repo_03_locality.toys.baseline.toy_T08_locality_matter_reference_fields_baseline
python -m repo_03_locality.toys.baseline.toy_T09_locality_semiclassical_local_disturbance_baseline
python -m repo_03_locality.toys.baseline.toy_T10_locality_effective_only_baseline
```

### Stress Tests
```bash
python -m repo_03_locality.toys.stress.toy_T11_locality_remove_coordinates_stress
python -m repo_03_locality.toys.stress.toy_T12_locality_remove_fixed_metric_stress
python -m repo_03_locality.toys.stress.toy_T13_locality_enforce_diffeomorphism_invariance_stress
python -m repo_03_locality.toys.stress.toy_T14_locality_relational_disturbance_instability_stress
python -m repo_03_locality.toys.stress.toy_T15_locality_boundary_gauge_artifact_stress
```

### Synthesis
```bash
python -m repo_03_locality.toys.synthesis.toy_T16_locality_minimal_requirement_set_synthesis
python -m repo_03_locality.toys.synthesis.toy_T17_locality_only_if_quasi_local_structure_synthesis
python -m repo_03_locality.toys.synthesis.toy_T18_locality_only_if_reference_fields_synthesis
python -m repo_03_locality.toys.synthesis.toy_T19_locality_hard_vs_soft_obstruction_map_synthesis
python -m repo_03_locality.toys.synthesis.toy_T20_locality_final_invariant_locality_result_synthesis
```
