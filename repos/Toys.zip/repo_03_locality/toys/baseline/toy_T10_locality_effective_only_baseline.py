"""
Repo 3 — T10 Effective-Only Locality Classification (Baseline Closure)

Purpose:
Classify all baseline locality notions as EFFECTIVE-ONLY
when they rely on background, semiclassical, observer,
or anchoring scaffolding.
"""

# ---------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------

effective_only_locality_notions = {
    "fixed_background_locality": [
        "fixed_background",
        "metric_structure",
        "coordinate_system",
        "region_decomposition",
        "observer_access",
    ],
    "quasi_local_constructions": [
        "metric_structure",
        "region_decomposition",
        "gauge_fixing",
        "observer_access",
    ],
    "matter_reference_field_locality": [
        "reference_fields",
        "stable_field_dynamics",
        "observer_access",
        "gauge_fixing_or_relational_choice",
    ],
    "semiclassical_locality": [
        "semiclassical_limit",
        "effective_metric_structure",
        "approximate_region_decomposition",
        "observer_access",
    ],
}

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T10 Effective-Only Locality Classification\n")

    print("Classification rule:")
    print(
        "Any locality notion that relies on background structure,\n"
        "observer access, gauge fixing, anchoring, or semiclassical\n"
        "approximations is classified as EFFECTIVE-ONLY.\n"
    )

    for notion, deps in effective_only_locality_notions.items():
        print(f"- {notion}: effective-only")
        print("  Requires:")
        for d in deps:
            print(f"   - {d}")
        print("")

    print("Note:")
    print(
        "This classification does NOT deny the usefulness of locality.\n"
        "It prepares the question: what survives when this scaffolding is removed?"
    )


if __name__ == "__main__":
    report()
