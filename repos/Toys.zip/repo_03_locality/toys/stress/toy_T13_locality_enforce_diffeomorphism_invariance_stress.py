"""
Repo 3 — T13 Enforce Full Diffeomorphism Invariance (Stress Test)

Purpose:
Enforce the constraint that only diffeomorphism-invariant statements
are physical, and record which locality notions lose invariant meaning.
"""

# ---------------------------------------------------------------------
# Enforced constraint
# ---------------------------------------------------------------------

enforced_constraint = (
    "full_diffeomorphism_invariance",
    "Only diffeomorphism-invariant / gauge-invariant statements are physical."
)

# ---------------------------------------------------------------------
# Locality notions under stress
# ---------------------------------------------------------------------

reports = [
    (
        "Coordinate-local neighborhoods are not invariant",
        ["coordinate_system"],
        "Coordinate-local support depends on chart choice and is not physical under full diffeomorphism invariance."
    ),
    (
        "Region decomposition is not a primitive invariant",
        ["region_decomposition"],
        "Region splits typically depend on embedding data or coordinates; without anchoring they are gauge-relative."
    ),
    (
        "Distance-based locality is not primitive",
        ["metric_structure"],
        "Distances require metric structure and identification of points/events; under full invariance these become relational and nonlocal."
    ),
    (
        "Boundary/interface notions lose invariant meaning",
        ["boundary_anchor"],
        "Boundaries require an anchor (asymptotic structure or equivalent). Without it, interfaces are gauge-relative constructions."
    ),
    (
        "Local disturbance becomes unformulable as a primitive",
        ["region_decomposition", "coordinate_system"],
        "Defining 'a disturbance supported in region R' presumes a gauge-invariant region notion."
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T13 Enforce Full Diffeomorphism Invariance (Stress Test)\n")

    name, desc = enforced_constraint
    print("Enforced constraint:\n")
    print(f"- {name}: {desc}\n")

    print("Stress-test result: evaluate which locality notions lose invariant meaning.\n")

    for title, relied_on, explanation in reports:
        print(f"• {title}")
        print("  Non-invariant primitives typically relied upon:")
        for r in relied_on:
            print(f"   - {r}")
        print(f"  Explanation: {explanation}\n")

    print("Note:")
    print(
        "This toy does NOT attempt relational repairs.\n"
        "If locality survives, it must be reformulated invariantly in later work."
    )


if __name__ == "__main__":
    report()
