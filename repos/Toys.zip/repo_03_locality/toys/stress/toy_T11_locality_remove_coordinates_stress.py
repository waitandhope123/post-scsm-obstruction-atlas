"""
Repo 3 — T11 Remove Fixed Background / Coordinates (Stress Test)

Purpose:
Test locality notions when fixed background geometry
and coordinate structure are removed.
"""

# ---------------------------------------------------------------------
# Retained assumptions
# ---------------------------------------------------------------------

retained_assumptions = [
    ("metric_structure", "A metric exists but may be dynamical."),
    ("observer_access", "Observers still exist."),
]

# ---------------------------------------------------------------------
# Removed assumptions
# ---------------------------------------------------------------------

removed_assumptions = [
    ("fixed_background", "Geometry is no longer fixed."),
    ("coordinate_system", "Coordinates have no invariant meaning."),
]

# ---------------------------------------------------------------------
# Stress-test failures
# ---------------------------------------------------------------------

failures = [
    (
        "Neighborhood identification collapses",
        ["fixed_background", "coordinate_system"],
        "Without fixed geometry and coordinates, neighborhoods cannot be identified invariantly."
    ),
    (
        "Region boundaries become frame-dependent",
        ["fixed_background"],
        "Region decomposition tied to geometry fluctuates under dynamics."
    ),
    (
        "Local disturbance loses meaning",
        ["fixed_background", "coordinate_system"],
        "Disturbance support cannot be defined without stable regions."
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T11 Remove Fixed Background / Coordinates (Stress Test)\n")

    print("Retained assumptions:\n")
    for name, desc in retained_assumptions:
        print(f"- {name}: {desc}")
    print("")

    print("Removed assumptions:\n")
    for name, desc in removed_assumptions:
        print(f"- {name}: {desc}")
    print("")

    print("Stress-test failures triggered:\n")
    for title, missing, explanation in failures:
        print(f"• {title}")
        print("  Missing / destabilized:")
        for m in missing:
            print(f"   - {m}")
        print(f"  Explanation: {explanation}\n")

    print("Note:")
    print(
        "This toy does NOT yet enforce full diffeomorphism invariance.\n"
        "It shows that locality already becomes unstable when geometry is dynamical."
    )


if __name__ == "__main__":
    report()
