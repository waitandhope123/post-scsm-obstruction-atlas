"""
Repo 3 — T18 'Only If Reference / Anchoring Structure' (Synthesis)

Purpose:
State the conditional necessity of reference or anchoring structures
to stabilize locality notions invariantly.
"""

# ---------------------------------------------------------------------
# Claim
# ---------------------------------------------------------------------

claim = (
    "Locality is ONLY POSSIBLE IF some reference or anchoring structure exists "
    "that stabilizes regions, boundaries, and disturbance interfaces."
)

# ---------------------------------------------------------------------
# Required structure
# ---------------------------------------------------------------------

required_structure = (
    "reference_or_anchor_structure",
    "Some invariant anchoring mechanism exists (e.g., asymptotic boundary, "
    "reference fields, or equivalent) to stabilize locality claims."
)

# ---------------------------------------------------------------------
# Supporting evidence
# ---------------------------------------------------------------------

supporting_evidence = [
    "T13: Full diffeomorphism invariance removes coordinate and region primitives.",
    "T14: Relational locality drifts without stable reference fields.",
    "T15: Boundary notions become gauge artifacts without anchoring.",
    "Known successes (e.g., semiclassical locality) rely on implicit anchors.",
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T18 'Only If Reference / Anchoring Structure' (Synthesis)\n")

    print("Claim:\n")
    print(f"{claim}\n")

    name, desc = required_structure
    print("Required structure:\n")
    print(f"- {name}: {desc}\n")

    print("Supporting evidence:\n")
    for e in supporting_evidence:
        print(f"- {e}")
    print("")

    print("Clarifications:")
    print(
        "- This does NOT assert reference structures are fundamental.\n"
        "- It allows for unknown anchoring mechanisms.\n"
        "- It records that no fully anchor-free locality construction is known.\n"
    )

    print("Status:")
    print("This is a CONDITIONAL necessity statement, not a no-go theorem.")


if __name__ == "__main__":
    report()
