"""
Repo 3 — T19 Hard vs Soft Obstruction Map (Synthesis)

Purpose:
Classify which obstructions to locality are hard (principle-level)
and which are soft (open but unsolved).
"""

# ---------------------------------------------------------------------
# Hard obstructions
# ---------------------------------------------------------------------

hard_obstructions = [
    "Without region or equivalent structure, locality claims are not formulable (T12).",
    "Full diffeomorphism invariance removes coordinate-local and region-based primitives (T13).",
    "Without invariant anchoring, boundaries and interfaces are gauge artifacts (T15).",
    "Local disturbance requires a definable support/interface; without it, locality collapses (T11–T13).",
]

# ---------------------------------------------------------------------
# Soft obstructions
# ---------------------------------------------------------------------

soft_obstructions = [
    "Relational locality may exist but is unstable without additional scaffolding (T14).",
    "Unknown anchoring mechanisms could exist beyond boundaries or reference fields (T18).",
    "Quasi-local constructions may survive in restricted regimes but are not fundamental (T07–T09).",
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T19 Hard vs Soft Obstruction Map (Synthesis)\n")

    print("HARD obstructions (principle-level):\n")
    for h in hard_obstructions:
        print(f"- {h}")
    print("")

    print("SOFT obstructions (no known solution, but not ruled out):\n")
    for s in soft_obstructions:
        print(f"- {s}")
    print("")

    print("Interpretation rule:")
    print(
        "- HARD obstructions block locality unless assumptions are reintroduced.\n"
        "- SOFT obstructions indicate open design space with no known realization."
    )


if __name__ == "__main__":
    report()
