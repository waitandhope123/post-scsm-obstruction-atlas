"""
Repo 3 — T01 Locality Definition Calibration

Purpose:
Surface common definitions of 'locality' and explicitly list
the assumptions required to even state them.

No claims are made about fundamentality or physical validity.
"""

from repo_03_locality.locality_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="A global or preferred time parameter exists.",
    category="background"
)

fixed_background = Assumption(
    name="fixed_background",
    description="Spacetime geometry is fixed and non-dynamical.",
    category="background"
)

coordinate_system = Assumption(
    name="coordinate_system",
    description="A coordinate chart exists with physical meaning.",
    category="background"
)

metric_structure = Assumption(
    name="metric_structure",
    description="A metric exists to define distance or causal separation.",
    category="background"
)

hilbert_space_factorization = Assumption(
    name="hilbert_space_factorization",
    description="The total Hilbert space factorizes into subsystems or regions.",
    category="locality"
)

observer_access = Assumption(
    name="observer_access",
    description="An observer can probe or act on localized regions.",
    category="observer"
)

gauge_fixing = Assumption(
    name="gauge_fixing",
    description="Gauge redundancy is partially fixed to define regions or supports.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Locality concepts
# ---------------------------------------------------------------------

locality_concepts = [
    Concept(
        name="spatial_locality_classical",
        required_assumptions=[
            fixed_background,
            coordinate_system,
            metric_structure
        ]
    ),
    Concept(
        name="causal_locality_relativistic",
        required_assumptions=[
            fixed_background,
            metric_structure
        ]
    ),
    Concept(
        name="operator_locality_qft",
        required_assumptions=[
            hilbert_space_factorization,
            metric_structure,
            gauge_fixing
        ]
    ),
    Concept(
        name="subsystem_locality_quantum_information",
        required_assumptions=[
            hilbert_space_factorization,
            observer_access
        ]
    ),
    Concept(
        name="relational_locality_via_reference_fields",
        required_assumptions=[
            observer_access,
            gauge_fixing
        ]
    ),
    Concept(
        name="bare_diffeomorphism_invariant_relation",
        required_assumptions=[]
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T01 Locality Definition Calibration\n")

    for concept in locality_concepts:
        print(f"Definition: {concept.name}")
        if concept.required_assumptions:
            print("  Requires:")
            for a in concept.required_assumptions:
                print(f"   - {a}")
        else:
            print("  Requires: (none)")
        print("")

    print("Note:")
    print(
        "This toy does NOT decide which notions of locality are meaningful.\n"
        "It only records what structure is required to even state them."
    )


if __name__ == "__main__":
    report()
