"""
Repo 3 — T04 Boundary Concept Dependency Calibration

Purpose:
Surface the assumptions required to even define 'boundary',
'interface', or 'edge' notions associated with locality.
"""

from repo_03_locality.locality_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

region_decomposition = Assumption(
    name="region_decomposition",
    description="Space or degrees of freedom can be decomposed into regions.",
    category="locality"
)

metric_structure = Assumption(
    name="metric_structure",
    description="A metric exists to define adjacency or separation.",
    category="background"
)

coordinate_system = Assumption(
    name="coordinate_system",
    description="Coordinates exist to label regions and their boundaries.",
    category="background"
)

hilbert_space_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Hilbert space factorizes into subsystems associated with regions.",
    category="locality"
)

gauge_fixing = Assumption(
    name="gauge_fixing",
    description="Gauge redundancy is fixed to identify subregions or edges.",
    category="gauge"
)

boundary_anchor = Assumption(
    name="boundary_anchor",
    description="A fixed boundary or anchor exists to define interfaces.",
    category="boundary"
)

# ---------------------------------------------------------------------
# Boundary-related concepts
# ---------------------------------------------------------------------

boundary_concepts = [
    Concept(
        name="spatial_boundary_of_region",
        required_assumptions=[
            region_decomposition,
            metric_structure
        ]
    ),
    Concept(
        name="coordinate_defined_interface",
        required_assumptions=[
            coordinate_system,
            region_decomposition
        ]
    ),
    Concept(
        name="subsystem_interface_quantum",
        required_assumptions=[
            hilbert_space_factorization,
            gauge_fixing
        ]
    ),
    Concept(
        name="asymptotic_boundary_anchor",
        required_assumptions=[
            boundary_anchor
        ]
    ),
    Concept(
        name="bare_invariant_relation_without_boundary",
        required_assumptions=[]
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T04 Boundary Concept Dependency Calibration\n")

    for concept in boundary_concepts:
        print(f"Boundary notion: {concept.name}")
        if concept.required_assumptions:
            print("  Requires:")
            for a in concept.required_assumptions:
                print(f"   - {a}")
        else:
            print("  Requires: (none)")
        print("")

    print("Observation:")
    print(
        "Boundary and interface notions presuppose region structure,\n"
        "factorization, coordinates, or anchoring.\n"
        "Fully invariant formulations lack primitive boundary concepts."
    )


if __name__ == "__main__":
    report()
