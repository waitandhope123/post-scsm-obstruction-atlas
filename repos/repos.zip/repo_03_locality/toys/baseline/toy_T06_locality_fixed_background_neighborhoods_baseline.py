"""
Repo 3 — T06 Fixed Background Neighborhoods (Baseline)

Purpose:
Demonstrate that standard locality notions are well-defined
when a fixed background, metric, and region structure are assumed.

This is a positive control, not a fundamental claim.
"""

# ---------------------------------------------------------------------
# Baseline assumptions
# ---------------------------------------------------------------------

baseline_assumptions = [
    ("fixed_background", "Spacetime geometry is fixed and non-dynamical."),
    ("metric_structure", "A metric exists to define distance and adjacency."),
    ("coordinate_system", "Coordinates exist with physical meaning."),
    ("region_decomposition", "Degrees of freedom can be decomposed into regions."),
    ("observer_access", "An observer can probe localized regions."),
]

# ---------------------------------------------------------------------
# Locality notions enabled
# ---------------------------------------------------------------------

enabled_locality_notions = [
    ("spatial_neighborhood", ["metric_structure", "coordinate_system"]),
    ("finite_region_support", ["region_decomposition", "metric_structure"]),
    ("local_disturbance", ["region_decomposition", "observer_access"]),
    ("boundary_of_region", ["region_decomposition", "metric_structure"]),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T06 Fixed Background Neighborhoods (Baseline)\n")

    print("Baseline assumptions explicitly in force:\n")
    for name, desc in baseline_assumptions:
        print(f"- {name}: {desc}")
    print("")

    print("Locality notions enabled by these assumptions:\n")
    for notion, deps in enabled_locality_notions:
        print(f"- {notion}")
        print(f"    requires: {', '.join(deps)}")
    print("")

    print("Result:")
    print(
        "With a fixed background, metric, and region structure,\n"
        "standard locality notions (neighborhoods, boundaries,\n"
        "and local disturbances) are well-defined.\n"
    )

    print("Note:")
    print(
        "This toy does NOT claim these assumptions hold fundamentally.\n"
        "It establishes a baseline regime against which removals are tested."
    )


if __name__ == "__main__":
    report()
