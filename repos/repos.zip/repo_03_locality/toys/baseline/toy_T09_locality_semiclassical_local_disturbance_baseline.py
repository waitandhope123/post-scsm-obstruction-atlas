"""
Repo 3 — T09 Semiclassical Local Disturbance (Baseline)

Purpose:
Record that locality is well-defined in semiclassical regimes
where geometry, causal structure, and observers are approximate but stable.
"""

# ---------------------------------------------------------------------
# Baseline assumptions
# ---------------------------------------------------------------------

baseline_assumptions = [
    ("semiclassical_limit", "An approximate classical spacetime exists."),
    ("effective_metric_structure", "An effective metric defines distances and causality."),
    ("approximate_region_decomposition", "Regions can be defined approximately."),
    ("observer_access", "Observers exist within the semiclassical description."),
]

# ---------------------------------------------------------------------
# Locality notions enabled
# ---------------------------------------------------------------------

enabled_locality_notions = [
    ("effective_local_disturbance", ["effective_metric_structure", "approximate_region_decomposition"]),
    ("approximate_causal_neighborhood", ["effective_metric_structure"]),
    ("semiclassical_boundary", ["approximate_region_decomposition"]),
    ("observer_relative_locality", ["observer_access"]),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T09 Semiclassical Local Disturbance (Baseline)\n")

    print("Baseline assumptions explicitly in force:\n")
    for name, desc in baseline_assumptions:
        print(f"- {name}: {desc}")
    print("")

    print("Locality notions enabled by these assumptions:\n")
    for notion, deps in enabled_locality_notions:
        print(f"- {notion}")
        print(f"    requires: {', '.join(deps)}")
    print("")

    print("Result:")
    print(
        "In a semiclassical regime, locality is meaningful\n"
        "as an effective, observer-relative notion.\n"
    )

    print("Note:")
    print(
        "This toy does NOT claim semiclassical locality is fundamental.\n"
        "It records its effective validity only."
    )


if __name__ == "__main__":
    report()
