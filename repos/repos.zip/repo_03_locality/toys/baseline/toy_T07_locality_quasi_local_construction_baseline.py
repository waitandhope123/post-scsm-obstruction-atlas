"""
Repo 3 — T07 Quasi-Local Construction (Baseline)

Purpose:
Examine quasi-local notions of locality and record
what assumptions they still rely on.

Quasi-local ≠ background-free; this is a baseline diagnostic.
"""

# ---------------------------------------------------------------------
# Baseline assumptions
# ---------------------------------------------------------------------

baseline_assumptions = [
    ("metric_structure", "A metric exists to define surfaces or regions."),
    ("region_decomposition", "Regions can be defined (even if approximately)."),
    ("gauge_fixing", "Gauge choices are made to define quasi-local quantities."),
    ("observer_access", "An observer can specify or measure quasi-local data."),
]

# ---------------------------------------------------------------------
# Quasi-local notions enabled
# ---------------------------------------------------------------------

enabled_quasi_local_notions = [
    ("quasi_local_energy", ["metric_structure", "gauge_fixing"]),
    ("finite_surface_observable", ["metric_structure", "region_decomposition"]),
    ("approximate_boundary", ["region_decomposition", "gauge_fixing"]),
    ("coarse_grained_region", ["observer_access", "region_decomposition"]),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T07 Quasi-Local Construction (Baseline)\n")

    print("Baseline assumptions explicitly in force:\n")
    for name, desc in baseline_assumptions:
        print(f"- {name}: {desc}")
    print("")

    print("Quasi-local notions enabled by these assumptions:\n")
    for notion, deps in enabled_quasi_local_notions:
        print(f"- {notion}")
        print(f"    requires: {', '.join(deps)}")
    print("")

    print("Result:")
    print(
        "Quasi-local constructions relax strict locality\n"
        "but still rely on metric structure, region definitions,\n"
        "gauge fixing, and observer specification.\n"
    )

    print("Note:")
    print(
        "This toy does NOT claim quasi-local notions are invalid.\n"
        "It records that they are not fully background-free."
    )


if __name__ == "__main__":
    report()
