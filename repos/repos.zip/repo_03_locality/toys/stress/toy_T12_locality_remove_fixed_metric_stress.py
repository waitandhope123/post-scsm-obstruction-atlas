"""
Repo 3 — T12 Remove Region Decomposition / Fixed Metric (Stress Test)

Purpose:
Test locality notions when region decomposition and
stable metric structure are removed.
"""

# ---------------------------------------------------------------------
# Retained assumptions
# ---------------------------------------------------------------------

retained_assumptions = [
    ("observer_access", "Observers still exist."),
]

# ---------------------------------------------------------------------
# Removed assumptions
# ---------------------------------------------------------------------

removed_assumptions = [
    ("metric_structure", "No stable metric exists to define distances."),
    ("region_decomposition", "Degrees of freedom cannot be cleanly partitioned into regions."),
]

# ---------------------------------------------------------------------
# Stress-test failures
# ---------------------------------------------------------------------

failures = [
    (
        "Distance-based locality collapses",
        ["metric_structure"],
        "Without a metric, near/far distinctions are not definable."
    ),
    (
        "Region-based support is undefined",
        ["region_decomposition"],
        "No invariant notion of region exists to support locality claims."
    ),
    (
        "Boundary notions collapse",
        ["metric_structure", "region_decomposition"],
        "Boundaries require region separation and adjacency."
    ),
    (
        "Local disturbance becomes unformulable",
        ["region_decomposition"],
        "There is no place to localize a disturbance."
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T12 Remove Region Decomposition / Fixed Metric (Stress Test)\n")

    print("Retained assumptions:\n")
    for name, desc in retained_assumptions:
        print(f"- {name}: {desc}")
    print("")

    print("Removed assumptions:\n")
    for name, desc in removed_assumptions:
        print(f"- {name}: {desc}")
    print("")

    print("Stress-test failures triggered:\n")
    for title, missing, explanation in failures:
        print(f"• {title}")
        print("  Missing / destabilized:")
        for m in missing:
            print(f"   - {m}")
        print(f"  Explanation: {explanation}\n")

    print("Note:")
    print(
        "This toy does NOT enforce gauge or diffeomorphism invariance.\n"
        "It shows locality fails even before those constraints are imposed."
    )


if __name__ == "__main__":
    report()
