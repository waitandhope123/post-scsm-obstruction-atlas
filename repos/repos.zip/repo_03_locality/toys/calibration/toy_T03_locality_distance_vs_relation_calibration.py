"""
Repo 3 — T03 Distance vs Relational Locality Calibration

Purpose:
Distinguish distance-based locality from purely relational notions,
and record what structure is required to even state distance claims.
"""

from repo_03_locality.locality_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

metric_structure = Assumption(
    name="metric_structure",
    description="A metric exists to define distances or causal separation.",
    category="background"
)

coordinate_system = Assumption(
    name="coordinate_system",
    description="A coordinate system exists to label positions.",
    category="background"
)

relational_reference = Assumption(
    name="relational_reference",
    description="Some reference entity exists to define relations.",
    category="relational"
)

observer_access = Assumption(
    name="observer_access",
    description="An observer can identify and compare relations.",
    category="observer"
)

# ---------------------------------------------------------------------
# Locality notions
# ---------------------------------------------------------------------

locality_concepts = [
    Concept(
        name="distance_based_locality",
        required_assumptions=[
            metric_structure,
            coordinate_system
        ]
    ),
    Concept(
        name="causal_cone_locality",
        required_assumptions=[
            metric_structure
        ]
    ),
    Concept(
        name="pure_relational_locality",
        required_assumptions=[
            relational_reference,
            observer_access
        ]
    ),
    Concept(
        name="bare_invariant_relation_without_distance",
        required_assumptions=[]
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T03 Distance vs Relational Locality Calibration\n")

    for concept in locality_concepts:
        print(f"Locality notion: {concept.name}")
        if concept.required_assumptions:
            print("  Requires:")
            for a in concept.required_assumptions:
                print(f"   - {a}")
        else:
            print("  Requires: (none)")
        print("")

    print("Observation:")
    print(
        "Distance-based locality presupposes metric structure and often coordinates.\n"
        "Pure relational locality avoids distance but becomes weak and observer-dependent,\n"
        "often insufficient for defining disturbance regions or boundaries."
    )


if __name__ == "__main__":
    report()
