"""
Repo 3 — T05 Locality Assumption Taxonomy Calibration

Purpose:
Consolidate all assumptions implicitly used in locality notions
into a clear, categorized registry.

No assumptions are asserted fundamental.
"""

# ---------------------------------------------------------------------
# Assumption registry
# ---------------------------------------------------------------------

assumption_registry = {
    "background": [
        ("preferred_time", "A global or preferred time parameter exists."),
        ("fixed_background", "Spacetime geometry is fixed and non-dynamical."),
        ("coordinate_system", "Coordinates exist with physical meaning."),
        ("metric_structure", "A metric exists to define distance or causality."),
    ],
    "locality": [
        ("hilbert_space_factorization", "Hilbert space factorizes into subsystems or regions."),
        ("region_decomposition", "Degrees of freedom can be decomposed into regions."),
    ],
    "observer": [
        ("observer_access", "An observer can probe or act on localized regions."),
    ],
    "gauge": [
        ("gauge_fixing", "Gauge redundancy is fixed to define supports or regions."),
    ],
    "boundary": [
        ("boundary_anchor", "A fixed boundary or anchor structure exists."),
    ],
    "relational": [
        ("relational_reference", "Reference entities exist to define relations."),
    ],
}

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T05 Locality Assumption Taxonomy Calibration\n")

    total = 0
    for category, items in assumption_registry.items():
        print(f"Category: {category}")
        for name, desc in items:
            print(f" - {name}: {desc}")
            total += 1
        print("")

    print(f"Total assumptions recorded: {total}\n")

    print("Note:")
    print(
        "No assumption is claimed to be fundamental or non-fundamental.\n"
        "This taxonomy exists solely to support explicit assumption removal\n"
        "in later stress tests."
    )


if __name__ == "__main__":
    report()
