"""
Repo 3 — T02 Locality Coordinate Dependence Calibration

Purpose:
Show how common locality notions depend on coordinate choices
and background structure, even before enforcing diffeomorphism invariance.
"""

from repo_03_locality.locality_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

coordinate_system = Assumption(
    name="coordinate_system",
    description="A coordinate chart exists with physical meaning.",
    category="background"
)

metric_structure = Assumption(
    name="metric_structure",
    description="A metric exists to define distance or causal separation.",
    category="background"
)

gauge_fixing = Assumption(
    name="gauge_fixing",
    description="Gauge redundancy is fixed to identify regions or supports.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Locality notions under coordinate change
# ---------------------------------------------------------------------

locality_notions = [
    Concept(
        name="point_localization",
        required_assumptions=[
            coordinate_system
        ]
    ),
    Concept(
        name="finite_region_support",
        required_assumptions=[
            coordinate_system,
            metric_structure
        ]
    ),
    Concept(
        name="operator_support_region",
        required_assumptions=[
            coordinate_system,
            gauge_fixing
        ]
    ),
    Concept(
        name="coordinate_free_relational_statement",
        required_assumptions=[]
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T02 Locality Coordinate Dependence Calibration\n")

    for concept in locality_notions:
        print(f"Locality notion: {concept.name}")
        if concept.required_assumptions:
            print("  Requires:")
            for a in concept.required_assumptions:
                print(f"   - {a}")
        else:
            print("  Requires: (none)")
        print("")

    print("Observation:")
    print(
        "Most standard locality notions require coordinates or gauge fixing.\n"
        "Coordinate-free statements tend to be relational and weak,\n"
        "often insufficient to support disturbance, boundary, or interface notions."
    )


if __name__ == "__main__":
    report()
