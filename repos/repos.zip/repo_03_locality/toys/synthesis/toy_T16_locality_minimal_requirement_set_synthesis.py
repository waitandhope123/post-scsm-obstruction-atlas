"""
Repo 3 — T16 Minimal Requirement Set (Synthesis)

Purpose:
Extract the minimal requirement atoms needed for locality-like notions
to be formulable as physical statements.
"""

# ---------------------------------------------------------------------
# Requirement atoms
# ---------------------------------------------------------------------

requirements = [
    ("stable_distinguishability", "A stable notion of distinguishing states or configurations exists."),
    ("region_or_equivalent_structure", "Some stable structure exists that can play the role of a region or support."),
    ("disturbance_interface_definability", "A notion of where/what constitutes a disturbance is definable."),
    ("boundary_or_interface_identifiability", "Interfaces or boundaries can be identified in a stable way."),
    ("observer_or_reference_structure", "Some reference or observer structure anchors locality statements."),
    ("gauge_invariant_formulation", "All locality claims can be stated invariantly under diffeomorphisms."),
]

# ---------------------------------------------------------------------
# Dependency ledger
# ---------------------------------------------------------------------

dependency_ledger = {
    "local_disturbance": [
        "region_or_equivalent_structure",
        "disturbance_interface_definability",
        "gauge_invariant_formulation",
    ],
    "boundary_definition": [
        "region_or_equivalent_structure",
        "boundary_or_interface_identifiability",
        "gauge_invariant_formulation",
    ],
    "local_interaction": [
        "stable_distinguishability",
        "region_or_equivalent_structure",
        "gauge_invariant_formulation",
    ],
}

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 3 — T16 Minimal Requirement Set (Synthesis)\n")

    print("Requirement atoms:\n")
    for name, desc in requirements:
        print(f"- {name}: {desc}")
    print("")

    print("Dependency ledger:\n")
    for concept, deps in dependency_ledger.items():
        print(f"- {concept}")
        for d in deps:
            print(f"   - {d}")
    print("")

    print("Interpretation rule:")
    print(
        "If any of the requirement atoms above cannot be defined\n"
        "in a fully gauge-invariant, background-free setting,\n"
        "then locality cannot be fundamental."
    )


if __name__ == "__main__":
    report()
