"""
Foundations for Repo 3 — Diffeomorphism-Invariant Locality

This file defines only minimal data structures.
NO logic, NO conclusions, NO analysis belongs here.
"""

class Assumption:
    def __init__(self, name, description, category):
        self.name = name
        self.description = description
        self.category = category

    def __repr__(self):
        return f"{self.name} [{self.category}]"


class Concept:
    def __init__(self, name, required_assumptions=None):
        self.name = name
        self.required_assumptions = required_assumptions or []

    def __repr__(self):
        return self.name
