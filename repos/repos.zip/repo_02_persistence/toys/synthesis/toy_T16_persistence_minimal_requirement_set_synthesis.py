"""
T16 — Minimal Requirement Set (Synthesis)

Purpose:
Derive a minimal set of requirement-atoms for persistence-as-information
from the calibration + baseline + stress results.

This toy produces:
- requirement atoms
- a dependency ledger for persistence claims
- an interpretation rule for later no-go / conditional results
"""

from repo_02_persistence.persistence_foundations import Assumption

# ---------------------------------------------------------------------
# Requirement atoms
# ---------------------------------------------------------------------

requirement_atoms = [
    Assumption(
        name="stable_state_distinguishability",
        description="A stable notion of distinguishability/inner product exists on the relevant state space.",
        category="gauge"
    ),
    Assumption(
        name="time_or_ordering_parameter",
        description="A time parameter or ordering notion exists to define 'before/after' persistence.",
        category="background"
    ),
    Assumption(
        name="retrieval_or_comparison_definability",
        description="A retrieval/comparison notion is definable (what counts as accessing or comparing the information).",
        category="observer"
    ),
    Assumption(
        name="reference_or_observer_structure",
        description="Some reference/observer structure exists to anchor comparisons or relational statements.",
        category="observer"
    ),
    Assumption(
        name="stable_information_carrier_identifiability",
        description="An identifiable carrier/record structure exists that can be tracked across configurations.",
        category="relational"
    ),
    Assumption(
        name="gauge_invariant_formulation",
        description="All claims can be made in fully gauge-invariant / diffeomorphism-invariant terms.",
        category="gauge"
    ),
]

# ---------------------------------------------------------------------
# Dependency ledger for persistence-as-information
# ---------------------------------------------------------------------

persistence_dependency_map = {
    "persistence_as_information": [
        "stable_state_distinguishability",
        "time_or_ordering_parameter",
        "retrieval_or_comparison_definability",
        "reference_or_observer_structure",
        "stable_information_carrier_identifiability",
        "gauge_invariant_formulation",
    ],
    "persistence_as_identity_only": [
        "time_or_ordering_parameter",
        "stable_state_distinguishability",
        "stable_information_carrier_identifiability",
        "gauge_invariant_formulation",
    ],
    "bare_invariant_existence": [
        "gauge_invariant_formulation",
    ],
}

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T16 Minimal Requirement Set (Synthesis)\n")

    print("Requirement atoms:\n")
    for a in requirement_atoms:
        print(f"- {a.name} [{a.category}]: {a.description}")

    print("\nDependency ledger:\n")
    for k, deps in persistence_dependency_map.items():
        print(f"- {k}")
        for d in deps:
            print(f"   - {d}")
        print("")

    print("Interpretation rule:")
    print(
        "If the atoms required for persistence-as-information cannot be defined\n"
        "in a fully gauge-invariant, background-free setting, then persistence-as-information\n"
        "cannot be fundamental.\n"
    )


if __name__ == "__main__":
    report()
