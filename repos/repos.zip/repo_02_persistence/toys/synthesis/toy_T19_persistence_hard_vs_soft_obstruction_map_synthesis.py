"""
T19 — Hard vs Soft Obstruction Map (Synthesis)

Purpose:
Consolidate all persistence obstructions identified across
calibration, baseline, and stress phases into a clear map.

This toy distinguishes:
- HARD obstructions: definitional or principle-level collapses
- SOFT obstructions: absence of known constructions, but not proven impossible
"""

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T19 Hard vs Soft Obstruction Map (Synthesis)\n")

    print("HARD obstructions (principle-level):\n")
    print(
        "1. Without time or ordering, persistence is not definable (T11).\n"
        "2. Without retrieval/comparison and reference structure, persistence-as-information collapses (T03, T12).\n"
        "3. Enforcing full gauge invariance erases distinguishability and identity tracking (T04, T13).\n"
        "4. Identity without distinguishability or carriers collapses into vacuous equivalence (T15).\n"
    )

    print("SOFT obstructions (no surviving construction known):\n")
    print(
        "1. Dynamical geometry destabilizes information carriers, but a universal theorem of loss is not proven (T14).\n"
        "2. Boundary-free, fully invariant reference structures are currently unknown (T17).\n"
        "3. Non-semiclassical mechanisms for persistence are not exhibited, but not ruled out in principle (T18).\n"
    )

    print("Interpretation rule:\n")
    print(
        "- HARD obstructions block persistence-as-information unless assumptions are reintroduced.\n"
        "- SOFT obstructions indicate open design space but no known solution under repo constraints.\n"
    )


if __name__ == "__main__":
    report()
