"""
T17 — 'Only If Reference Structure' (Synthesis)

Purpose:
State a necessary condition for persistence-as-information
derived from calibration, baseline, and stress results.

This toy records a CONDITIONAL necessity, not a proof of existence.
"""

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T17 'Only If Reference Structure' (Synthesis)\n")

    print("Claim:\n")
    print(
        "Persistence-as-information is ONLY POSSIBLE IF\n"
        "some reference or observer structure exists.\n"
    )

    print("Required structure:\n")
    print(
        "- reference_or_observer_structure [observer]\n"
        "  Some structure exists that anchors comparison, retrieval,\n"
        "  or relational statements required to define persistence.\n"
    )

    print("Supporting evidence (from earlier toys):\n")
    print(
        "- T03: Identity alone is insufficient without retrievability.\n"
        "- T04: Gauge averaging erases distinctions needed for persistence.\n"
        "- T11: Removing time/order collapses persistence.\n"
        "- T12: Removing observers/reference frames collapses persistence.\n"
        "- T15: Identity collapses without reference and distinguishability.\n"
    )

    print("Clarifications:\n")
    print(
        "- This does NOT require classical observers.\n"
        "- It allows for relational, emergent, or unknown reference structures.\n"
        "- It does NOT assert such structures are fundamental.\n"
    )

    print("Status:\n")
    print(
        "This is a CONDITIONAL necessity statement,\n"
        "not a constructive proposal or no-go theorem."
    )


if __name__ == "__main__":
    report()
