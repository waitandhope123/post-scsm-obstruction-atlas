"""
T06 — Persistence with Fixed Time Reference (Baseline)

Purpose:
Establish a baseline regime where persistence is uncontroversial
and well-defined: fixed time, observer, and retrieval.

This serves as a positive control before assumption removal.
"""

from repo_02_persistence.persistence_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Baseline assumptions explicitly in force
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="A global or preferred time parameter exists.",
    category="background"
)

external_observer = Assumption(
    name="external_observer",
    description="An observer exists who can compare states across time.",
    category="observer"
)

retrieval_operation = Assumption(
    name="retrieval_operation",
    description="A retrieval or readout operation exists.",
    category="observer"
)

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="A stable notion of distinguishability exists.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Persistence concept enabled by baseline
# ---------------------------------------------------------------------

classical_persistence = Concept(
    name="classical_memory_persistence",
    requires=[
        preferred_time,
        external_observer,
        retrieval_operation,
        stable_state_distinguishability
    ]
)

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T06 Fixed Time Reference Baseline\n")

    print("Baseline assumptions explicitly in force:\n")
    for a in classical_persistence.requires:
        print(f" - {a.name} [{a.category}]: {a.description}")

    print("\nPersistence status:")
    print(
        "With fixed time, an observer, retrieval operations, and stable "
        "distinguishability, persistence is well-defined and unproblematic."
    )

    print("\nNote:")
    print(
        "This toy does NOT claim these assumptions are fundamental.\n"
        "It establishes a baseline regime against which later removals are tested.\n"
    )


if __name__ == "__main__":
    report()
