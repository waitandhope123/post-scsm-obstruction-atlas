"""
T10 — Effective-Only Persistence Classification (Baseline Closure)

Purpose:
Classify all persistence notions that survive the baseline phase
as effective-only, in preparation for stress testing.

This toy does NOT deny usefulness.
It labels scope.
"""

from repo_02_persistence.persistence_foundations import Assumption

# ---------------------------------------------------------------------
# Classification rule
# ---------------------------------------------------------------------
# If a persistence notion relies on:
# - time (absolute, relational, or semiclassical),
# - observers or retrieval operations,
# - distinguishability structures,
# then it is classified as EFFECTIVE-ONLY.

# ---------------------------------------------------------------------
# Persistence notions and their required scaffolding
# ---------------------------------------------------------------------

persistence_cases = {
    "fixed_time_classical_persistence": [
        "preferred_time",
        "external_observer",
        "retrieval_operation",
        "stable_state_distinguishability",
    ],
    "external_memory_register_persistence": [
        "preferred_time",
        "external_memory_register",
        "external_observer",
        "retrieval_operation",
        "stable_state_distinguishability",
    ],
    "relational_clock_based_persistence": [
        "relational_clock",
        "external_observer",
        "retrieval_operation",
        "stable_state_distinguishability",
    ],
    "semiclassical_observer_dependent_persistence": [
        "semiclassical_limit",
        "preferred_time",
        "external_observer",
        "retrieval_operation",
        "stable_state_distinguishability",
    ],
}

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T10 Effective-Only Persistence Classification\n")

    print("Classification rule:")
    print(
        "Any persistence notion that depends on time, observers,\n"
        "retrieval operations, or distinguishability structures\n"
        "is classified as EFFECTIVE-ONLY.\n"
    )

    for name, deps in persistence_cases.items():
        print(f"- {name}: effective-only")
        print("  Requires:")
        for d in deps:
            print(f"   - {d}")
        print("")

    print("Note:")
    print(
        "This classification does not deny the practical reality of memory.\n"
        "It prepares the question: what survives when this scaffolding is removed?"
    )


if __name__ == "__main__":
    report()
