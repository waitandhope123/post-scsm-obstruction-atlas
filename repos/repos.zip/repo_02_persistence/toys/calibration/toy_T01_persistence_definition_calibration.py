"""
T01 — Persistence Definition Calibration

Purpose:
Catalog candidate meanings of "persistent information" and record
the assumptions required to even state them.

This toy:
- does NOT test whether persistence exists
- does NOT assume time, observers, or background structure by default
- exposes where persistence definitions quietly rely on forbidden structure
"""

from repo_02_persistence.persistence_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Assumptions that commonly sneak into persistence claims
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="A global or preferred time parameter exists.",
    category="background"
)

external_observer = Assumption(
    name="external_observer",
    description="An observer exists who can compare states across time.",
    category="observer"
)

reference_frame = Assumption(
    name="reference_frame",
    description="A fixed reference frame or coordinate system exists.",
    category="background"
)

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="A stable notion of distinguishability or inner product exists.",
    category="gauge"
)

retrieval_operation = Assumption(
    name="retrieval_operation",
    description="A retrieval or readout operation is definable.",
    category="observer"
)

relational_clock = Assumption(
    name="relational_clock",
    description="A relational clock or ordering variable exists.",
    category="relational"
)

# ---------------------------------------------------------------------
# Candidate definitions of persistence
# ---------------------------------------------------------------------

persistence_definitions = [

    Concept(
        name="classical_memory_persistence",
        requires=[
            preferred_time,
            external_observer,
            retrieval_operation
        ]
    ),

    Concept(
        name="quantum_state_persistence",
        requires=[
            preferred_time,
            stable_state_distinguishability,
            external_observer
        ]
    ),

    Concept(
        name="retrievability_based_persistence",
        requires=[
            retrieval_operation,
            external_observer,
            preferred_time
        ]
    ),

    Concept(
        name="relational_persistence_via_clock",
        requires=[
            relational_clock,
            stable_state_distinguishability
        ]
    ),

    Concept(
        name="gauge_invariant_label_persistence",
        requires=[
            stable_state_distinguishability
        ]
    ),

    Concept(
        name="bare_invariant_existence",
        requires=[]
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T01 Persistence Definition Calibration\n")

    for c in persistence_definitions:
        print(f"Definition: {c.name}")
        if not c.requires:
            print("  Requires: (none)")
        else:
            print("  Requires:")
            for a in c.requires:
                print(f"   - {a.name} [{a.category}]")
        print("")

    print("Note:")
    print(
        "This toy does NOT decide which definitions are meaningful.\n"
        "It only records what structure is required to even state them.\n"
    )


if __name__ == "__main__":
    report()
