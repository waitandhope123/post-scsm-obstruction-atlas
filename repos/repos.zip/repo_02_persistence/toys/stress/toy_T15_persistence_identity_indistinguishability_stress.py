"""
T15 — Identity Indistinguishability (Stress Test)

Purpose:
Demonstrate that without distinguishability, stable carriers,
and reference structure, 'identity over time/configuration'
collapses into an undefined or vacuous notion.

This closes the stress phase for persistence.
"""

from repo_02_persistence.persistence_foundations import Assumption, Failure

# ---------------------------------------------------------------------
# Enforced conditions
# ---------------------------------------------------------------------

full_gauge_invariance = Assumption(
    name="full_gauge_invariance",
    description="Only gauge-invariant equivalence classes are physical.",
    category="gauge"
)

dynamic_geometry = Assumption(
    name="dynamic_geometry",
    description="Geometry and relational structure are dynamical.",
    category="background"
)

# ---------------------------------------------------------------------
# Destabilized identity supports
# ---------------------------------------------------------------------

stable_state_distinguishability = Assumption(
    name="stable_state_distinguishability",
    description="No stable distinguishability structure survives.",
    category="gauge"
)

stable_carrier_structure = Assumption(
    name="stable_carrier_structure",
    description="No stable carrier can be identified across configurations.",
    category="relational"
)

reference_structure = Assumption(
    name="reference_structure",
    description="No external or relational reference remains.",
    category="observer"
)

# ---------------------------------------------------------------------
# Stress analysis
# ---------------------------------------------------------------------

failures = [
    Failure(
        message=(
            "Without distinguishability, there is no physical criterion "
            "for asserting that two states/configurations are the same."
        ),
        missing_assumptions=[stable_state_distinguishability]
    ),
    Failure(
        message=(
            "Without stable carriers, identity claims cannot be anchored "
            "to identifiable degrees of freedom."
        ),
        missing_assumptions=[stable_carrier_structure]
    ),
    Failure(
        message=(
            "Without reference structures, identity statements lack operational "
            "or relational meaning."
        ),
        missing_assumptions=[reference_structure]
    ),
    Failure(
        message=(
            "Under full gauge invariance and dynamical structure, 'identity' "
            "reduces to membership in an equivalence class, which does not "
            "support persistence-as-information."
        ),
        missing_assumptions=[]
    )
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 2 — T15 Identity Indistinguishability (Stress Test)\n")

    print("Enforced conditions:")
    print(f" - {full_gauge_invariance.name} [{full_gauge_invariance.category}]")
    print(f" - {dynamic_geometry.name} [{dynamic_geometry.category}]\n")

    print("Identity collapse reports:\n")
    for f in failures:
        print(f" • {f.message}")
        if f.missing_assumptions:
            print("   Would require:")
            for a in f.missing_assumptions:
                print(f"    - {a.name} [{a.category}]")
        print("")

    print("Conclusion:")
    print(
        "Without distinguishability, carriers, or reference structure,\n"
        "identity collapses into an indistinguishable equivalence class.\n"
        "Persistence-as-identity is therefore not physically meaningful."
    )


if __name__ == "__main__":
    report()
