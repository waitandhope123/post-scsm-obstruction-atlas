"""
T05 — QGEC Assumption Taxonomy Calibration

Purpose:
Consolidate all structural assumptions introduced in T01–T04 into a single,
explicit taxonomy.

This toy:
- introduces NO new assumptions
- draws NO conclusions
- performs NO stress tests

It exists to ensure that later removals are deliberate, explicit, and non-duplicative.
"""

from repo_01_qgec.qgec_foundations import Assumption

# ---------------------------------------------------------------------
# Consolidated assumption registry (from T01–T04)
# ---------------------------------------------------------------------

assumptions = [

    # Background / time structure
    Assumption(
        name="preferred_time",
        description="A global or preferred time parameter exists.",
        category="background"
    ),

    Assumption(
        name="fixed_background",
        description="Spacetime geometry is fixed and non-dynamical.",
        category="background"
    ),

    # Locality / subsystem structure
    Assumption(
        name="hilbert_space_factorization",
        description="Total Hilbert space factorizes into stable subsystems or regions.",
        category="locality"
    ),

    Assumption(
        name="locality",
        description="A meaningful notion of spatial or causal locality exists.",
        category="locality"
    ),

    # Observer / operational structure
    Assumption(
        name="external_environment",
        description="A separable environment exists that can be traced out.",
        category="observer"
    ),

    Assumption(
        name="external_observer_or_agent",
        description="An operational notion of an observer/decoder exists.",
        category="observer"
    ),

    Assumption(
        name="measurement_or_operational_access",
        description="Operational access exists to characterize disturbances or outcomes.",
        category="observer"
    ),

    # Gauge / representational structure
    Assumption(
        name="gauge_fixing",
        description="Gauge redundancy is partially or fully fixed.",
        category="gauge"
    ),

    Assumption(
        name="stable_inner_product",
        description="A stable notion of state distinguishability exists.",
        category="gauge"
    ),

    # Boundary / asymptotic structure
    Assumption(
        name="boundary_structure",
        description="A fixed boundary or asymptotic region exists.",
        category="boundary"
    ),

    # Semiclassical structure
    Assumption(
        name="semiclassical_limit",
        description="Quantum fields propagate on approximately classical spacetime.",
        category="semiclassical"
    ),
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T05 — Assumption Taxonomy Calibration\n")

    categories = {}
    for a in assumptions:
        categories.setdefault(a.category, []).append(a)

    for cat, items in categories.items():
        print(f"Category: {cat}")
        for a in items:
            print(f" - {a.name}: {a.description}")
        print("")

    print("Total assumptions recorded:", len(assumptions))
    print("")
    print("Note: No assumption is claimed to be fundamental or non-fundamental here.")
    print("This taxonomy exists solely to make later assumption removal explicit.\n")


if __name__ == "__main__":
    report()
