"""
T06 — QGEC Standard QEC on Fixed Background (Baseline)

Purpose:
Demonstrate that standard quantum error correction succeeds when strong,
textbook structural assumptions are explicitly present.

This toy:
- DOES assume a fixed background
- DOES assume a preferred time
- DOES assume subsystem factorization and locality
- DOES assume an external observer/decoder

It draws NO conclusions about whether these assumptions are fundamental.
It exists only to identify which assumptions are load-bearing when QEC works.
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Explicit baseline assumptions (drawn from T05 taxonomy)
# ---------------------------------------------------------------------

fixed_background = Assumption(
    name="fixed_background",
    description="Spacetime geometry is fixed and non-dynamical.",
    category="background"
)

preferred_time = Assumption(
    name="preferred_time",
    description="A global or preferred time parameter exists.",
    category="background"
)

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Total Hilbert space factorizes into stable subsystems.",
    category="locality"
)

locality = Assumption(
    name="locality",
    description="Errors act locally on subsystems.",
    category="locality"
)

external_environment = Assumption(
    name="external_environment",
    description="A separable environment exists that introduces noise.",
    category="observer"
)

external_observer_or_agent = Assumption(
    name="external_observer_or_agent",
    description="An agent/decoder exists to perform recovery operations.",
    category="observer"
)

measurement_or_operational_access = Assumption(
    name="measurement_or_operational_access",
    description="Operational access exists to characterize disturbances or outcomes.",
    category="observer"
)

stable_inner_product = Assumption(
    name="stable_inner_product",
    description="A stable Hilbert-space inner product exists.",
    category="gauge"
)

# ---------------------------------------------------------------------
# Standard QEC conceptual components
# ---------------------------------------------------------------------

logical_code_subspace = Concept(
    name="logical_code_subspace",
    requires=[stable_inner_product, hilbert_factorization]
)

local_noise_model = Concept(
    name="local_noise_model",
    requires=[preferred_time, hilbert_factorization, locality, external_environment]
)

syndrome_measurement = Concept(
    name="syndrome_measurement",
    requires=[preferred_time, external_observer_or_agent, measurement_or_operational_access]
)

recovery_operation = Concept(
    name="recovery_operation",
    requires=[preferred_time, hilbert_factorization, external_observer_or_agent]
)

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T06 — Standard QEC on Fixed Background (Baseline)\n")

    print("Baseline assumptions explicitly in force:\n")
    assumptions = [
        fixed_background,
        preferred_time,
        hilbert_factorization,
        locality,
        external_environment,
        external_observer_or_agent,
        measurement_or_operational_access,
        stable_inner_product
    ]

    for a in assumptions:
        print(f"- {a.name} [{a.category}]: {a.description}")
    print("")

    print("QEC components enabled by these assumptions:\n")
    components = [
        logical_code_subspace,
        local_noise_model,
        syndrome_measurement,
        recovery_operation
    ]

    for c in components:
        print(f"- {c.name}")
        for req in c.requires:
            print(f"    requires: {req.name} [{req.category}]")
    print("")

    print("Result:")
    print("With all baseline assumptions present, standard QEC is well-defined and operational.")
    print("This toy does NOT claim any of these assumptions hold in fundamental physics.\n")


if __name__ == "__main__":
    report()
