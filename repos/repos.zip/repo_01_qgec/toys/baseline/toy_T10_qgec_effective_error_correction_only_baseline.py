"""
T10 — QGEC Effective Error Correction Only (Baseline Closure)

Purpose:
Close the baseline phase by explicitly labeling which QEC-like notions are
"effective-only" because they rely on scaffolding that is expected to fail
in fully background-free, diffeomorphism-invariant regimes.

This toy:
- introduces no new physics
- proves nothing
- makes a bookkeeping distinction:
    effective-definable vs candidate-fundamental

It prepares the transition into stress tests (T11–T15).
"""

from repo_01_qgec.qgec_foundations import Assumption, Concept

# ---------------------------------------------------------------------
# Scaffolding assumptions that typically signal "effective-only"
# ---------------------------------------------------------------------

preferred_time = Assumption(
    name="preferred_time",
    description="A global or effective time parameter exists.",
    category="background"
)

hilbert_factorization = Assumption(
    name="hilbert_space_factorization",
    description="Stable subsystem factorization exists (system/region decomposition).",
    category="locality"
)

locality = Assumption(
    name="locality",
    description="A meaningful local notion exists (effective causal/spatial support).",
    category="locality"
)

external_observer_or_agent = Assumption(
    name="external_observer_or_agent",
    description="An operational agent/decoder exists.",
    category="observer"
)

boundary_structure = Assumption(
    name="boundary_structure",
    description="A fixed asymptotic boundary exists.",
    category="boundary"
)

semiclassical_limit = Assumption(
    name="semiclassical_limit",
    description="Approximate classical geometry exists with quantum fields on it.",
    category="semiclassical"
)

# ---------------------------------------------------------------------
# Representative QEC-like notions and what scaffolding they lean on
# ---------------------------------------------------------------------

standard_qec = Concept(
    name="standard_qec_fixed_background",
    requires=[preferred_time, hilbert_factorization, locality, external_observer_or_agent]
)

holographic_qec = Concept(
    name="holographic_qec_ads_cft_style",
    requires=[boundary_structure, semiclassical_limit, locality]
)

semiclassical_effective_qec = Concept(
    name="semiclassical_effective_qec_without_boundary",
    requires=[semiclassical_limit, preferred_time, locality, hilbert_factorization]
)

# ---------------------------------------------------------------------
# Classification logic (deliberately simple)
# ---------------------------------------------------------------------

def classify(concept: Concept):
    """
    Classification rule (repo-internal bookkeeping):
    If a concept requires any of the following,
    it is labeled 'effective-only' for purposes of later stress tests:

      - preferred_time
      - hilbert_space_factorization
      - locality
      - external_observer_or_agent
      - boundary_structure
      - semiclassical_limit

    This does NOT mean the concept is false.
    It means it is not established as fundamental by this repo's standards.
    """
    effective_scaffolding = {a.name for a in [
        preferred_time,
        hilbert_factorization,
        locality,
        external_observer_or_agent,
        boundary_structure,
        semiclassical_limit
    ]}

    used = {a.name for a in concept.requires}
    if used.intersection(effective_scaffolding):
        return "effective-only"
    return "candidate-fundamental"


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T10 — Effective Error Correction Only (Baseline Closure)\n")

    concepts = [standard_qec, holographic_qec, semiclassical_effective_qec]

    print("Classification rule:")
    print("If a QEC-like notion leans on time/factorization/locality/observer/boundary/semiclassical scaffolding,")
    print("we label it 'effective-only' for stress-testing purposes.\n")

    for c in concepts:
        label = classify(c)
        print(f"- {c.name}: {label}")
        print("  Requires:")
        for req in c.requires:
            print(f"   - {req.name} [{req.category}]")
        print("")

    print("Note: This toy does not deny the usefulness of these notions.")
    print("It merely prepares the later question: what survives when scaffolding is removed?\n")


if __name__ == "__main__":
    report()
