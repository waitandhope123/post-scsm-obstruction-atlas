"""
T17 — QGEC "Only If Subsystem Structure" (Synthesis)

Purpose:
Synthesize an explicit conditional statement:

QEC-like protected information is ONLY POSSIBLE IF
some stable subsystem-like (or equivalent) structure exists.

This toy:
- introduces no new assumptions
- makes no metaphysical claims
- records a conditional permission, not a construction

It sharpens the minimal requirement set from T16 into an "only if" gate.
"""

from repo_01_qgec.qgec_foundations import Assumption

# ---------------------------------------------------------------------
# Key requirement under examination
# ---------------------------------------------------------------------

subsystem_structure = Assumption(
    name="subsystem_or_equivalent_structure",
    description=(
        "Some stable, invariantly identifiable structure exists that plays the role of "
        "a subsystem/region/support for encoding, disturbance, and recovery."
    ),
    category="locality"
)

# ---------------------------------------------------------------------
# Supporting dependencies (from T16)
# ---------------------------------------------------------------------

dependent_requirements = [
    "noise_interface_definability",
    "recovery_or_retrieval_map_definability",
    "logical_operator_identification",
]

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T17 — 'Only If Subsystem Structure' (Synthesis)\n")

    print("Claim:\n")
    print(
        "Any QEC-like notion of protected information is ONLY POSSIBLE IF\n"
        "there exists some stable subsystem-like or equivalent structure.\n"
    )

    print("Key requirement:\n")
    print(f"- {subsystem_structure.name} [{subsystem_structure.category}]")
    print(f"  {subsystem_structure.description}\n")

    print("Reasoning summary (from prior toys):\n")
    for dep in dependent_requirements:
        print(f"- Without subsystem structure, '{dep}' is not formulable in a gauge-invariant way.")
    print("")

    print("Important clarifications:\n")
    print("- This does NOT require spatial locality in the classical sense.")
    print("- This does NOT require tensor-product factorization in advance.")
    print("- It DOES require some invariant structure that plays an equivalent role.\n")

    print("Status:\n")
    print("This is a CONDITIONAL necessity statement, not a proof of existence.\n")


if __name__ == "__main__":
    report()
