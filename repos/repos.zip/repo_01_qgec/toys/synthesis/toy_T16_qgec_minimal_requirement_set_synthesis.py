"""
T16 — QGEC Minimal Requirement Set (Synthesis)

Purpose:
Synthesize earlier calibration, baseline, and stress-test outputs into a
minimal requirement set for even FORMULATING QEC-like "protected information".

This toy:
- introduces no new physics
- does not repair failures
- does not declare impossibility

It outputs:
- a minimal set of structural requirements (as assumptions)
- a statement of which QEC components depend on them
"""

from repo_01_qgec.qgec_foundations import Assumption

# ---------------------------------------------------------------------
# Candidate requirement atoms (from T05 taxonomy + stress-test necessities)
# ---------------------------------------------------------------------

requirements = [

    Assumption(
        name="stable_state_distinguishability",
        description="A stable notion of distinguishability/inner product exists on the relevant state space.",
        category="gauge"
    ),

    Assumption(
        name="code_subspace_stability",
        description="A designated code subspace remains identifiable under the relevant dynamics.",
        category="gauge"
    ),

    Assumption(
        name="subsystem_or_equivalent_structure",
        description="Some stable subsystem/region structure exists to locate encoding and disturbances.",
        category="locality"
    ),

    Assumption(
        name="noise_interface_definability",
        description="A disturbance/noise class is definable (what counts as an error set E).",
        category="observer"
    ),

    Assumption(
        name="recovery_or_retrieval_map_definability",
        description="A recovery/decoding/retrieval notion is definable operationally.",
        category="observer"
    ),

    Assumption(
        name="time_or_ordering_parameter",
        description="A time parameter or ordering notion exists to compare pre/post disturbance and apply recovery.",
        category="background"
    ),

    Assumption(
        name="gauge_invariant_formulation",
        description="All claims can be made in fully gauge-invariant / diffeomorphism-invariant terms.",
        category="gauge"
    ),
]

# ---------------------------------------------------------------------
# Minimality summary (hand-coded bookkeeping from earlier toys)
# ---------------------------------------------------------------------

qec_components = {
    "code_subspace": [
        "stable_state_distinguishability",
        "code_subspace_stability",
        "gauge_invariant_formulation"
    ],
    "noise_model": [
        "subsystem_or_equivalent_structure",
        "noise_interface_definability",
        "time_or_ordering_parameter",
        "gauge_invariant_formulation"
    ],
    "recovery": [
        "recovery_or_retrieval_map_definability",
        "subsystem_or_equivalent_structure",
        "time_or_ordering_parameter",
        "gauge_invariant_formulation"
    ],
    "logical_operator_identification": [
        "subsystem_or_equivalent_structure",
        "gauge_invariant_formulation",
        "stable_state_distinguishability"
    ],
    "full_qec_claim_(corrects_error_set_E)": [
        "code_subspace",
        "noise_model",
        "recovery"
    ]
}

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nQGEC T16 — Minimal Requirement Set (Synthesis)\n")

    print("Requirement atoms:\n")
    req_by_name = {r.name: r for r in requirements}
    for r in requirements:
        print(f"- {r.name} [{r.category}]: {r.description}")
    print("")

    print("QEC component dependency map (synthetic ledger):\n")
    for comp, deps in qec_components.items():
        print(f"- {comp}")
        for d in deps:
            # component names may reference other components; mark them clearly
            if d in req_by_name:
                rr = req_by_name[d]
                print(f"    requires: {rr.name} [{rr.category}]")
            else:
                print(f"    requires: (component) {d}")
        print("")

    print("Interpretation rule:")
    print("If any atom above cannot be defined gauge-invariantly without background structure,")
    print("then QEC-like protected information cannot be fundamental.\n")


if __name__ == "__main__":
    report()
