## Repo 1 — Quantum Gravity Error Correction (QGEC)

### Calibration
```bash
python -m repo_01_qgec.toys.calibration.toy_T01_qgec_definition_calibration
python -m repo_01_qgec.toys.calibration.toy_T02_qgec_trivial_invariant_false_positive_calibration
python -m repo_01_qgec.toys.calibration.toy_T03_qgec_code_subspace_minimality_calibration
python -m repo_01_qgec.toys.calibration.toy_T04_qgec_noise_definition_dependency_calibration
python -m repo_01_qgec.toys.calibration.toy_T05_qgec_assumption_taxonomy_calibration
```

### Baseline
```bash
python -m repo_01_qgec.toys.baseline.toy_T06_qgec_standard_qec_fixed_background_baseline
python -m repo_01_qgec.toys.baseline.toy_T07_qgec_local_noise_subsystem_factorization_baseline
python -m repo_01_qgec.toys.baseline.toy_T08_qgec_holographic_code_with_boundary_baseline
python -m repo_01_qgec.toys.baseline.toy_T09_qgec_semiclassical_gravity_limit_baseline
python -m repo_01_qgec.toys.baseline.toy_T10_qgec_effective_error_correction_only_baseline
```

### Stress Tests
```bash
python -m repo_01_qgec.toys.stress.toy_T11_qgec_remove_fixed_background_stress
python -m repo_01_qgec.toys.stress.toy_T12_qgec_remove_local_noise_definition_stress
python -m repo_01_qgec.toys.stress.toy_T13_qgec_enforce_full_diffeomorphism_invariance_stress
python -m repo_01_qgec.toys.stress.toy_T14_qgec_dynamic_geometry_code_instability_stress
python -m repo_01_qgec.toys.stress.toy_T15_qgec_gauge_constraint_logical_operator_mixing_stress
```

### Synthesis
```bash
python -m repo_01_qgec.toys.synthesis.toy_T16_qgec_minimal_requirement_set_synthesis
python -m repo_01_qgec.toys.synthesis.toy_T17_qgec_only_if_subsystem_structure_synthesis
python -m repo_01_qgec.toys.synthesis.toy_T18_qgec_only_if_boundary_structure_synthesis
python -m repo_01_qgec.toys.synthesis.toy_T19_qgec_hard_vs_soft_obstruction_map_synthesis
python -m repo_01_qgec.toys.synthesis.toy_T20_qgec_final_no_go_or_conditional_result_synthesis
```
