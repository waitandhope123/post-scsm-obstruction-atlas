"""
Repo 4 — T16 Minimal Requirement Set (Synthesis)

Purpose:
Extract the minimal set of requirements that would be necessary
for relational observables to function as nontrivial information-bearing
physical quantities.
"""

# ---------------------------------------------------------------------
# Requirement atoms
# ---------------------------------------------------------------------

requirement_atoms = [
    ("stable_distinguishability", "A stable notion of distinguishability exists."),
    ("reference_or_anchor_structure", "Some stable anchoring structure exists to define relations."),
    ("observer_or_comparison_structure", "A structure exists to compare or retrieve relational values."),
    ("persistence_under_dynamics", "Relational observables remain identifiable under evolution."),
    ("nontrivial_informational_capacity", "Observables support more than trivial labels."),
    ("gauge_invariant_formulation", "All claims are definable under full gauge invariance."),
]

# ---------------------------------------------------------------------
# Dependency ledger
# ---------------------------------------------------------------------

dependency_ledger = {
    "relational_observable_as_information": [
        "stable_distinguishability",
        "reference_or_anchor_structure",
        "observer_or_comparison_structure",
        "persistence_under_dynamics",
        "nontrivial_informational_capacity",
        "gauge_invariant_formulation",
    ],
    "relational_observable_as_label_only": [
        "gauge_invariant_formulation",
    ],
}

# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 4 — T16 Minimal Requirement Set (Synthesis)\n")

    print("Requirement atoms:\n")
    for name, desc in requirement_atoms:
        print(f"- {name}: {desc}")
    print("")

    print("Dependency ledger:\n")
    for concept, reqs in dependency_ledger.items():
        print(f"- {concept}")
        for r in reqs:
            print(f"   - {r}")
        print("")

    print(
        "Interpretation rule:\n"
        "If the atoms required for relational observables as information\n"
        "cannot be defined in a fully gauge-invariant, background-free setting,\n"
        "then relational observables cannot be fundamental information carriers."
    )


if __name__ == "__main__":
    report()
