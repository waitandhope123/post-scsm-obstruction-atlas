"""
Repo 4 — T01 Relational Observable Definition Calibration

Purpose:
Catalog common notions of relational observables and record
what structure is required to even state them.
"""

from repo_04_relational.relational_foundations import Assumption, Concept


# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

assumptions = {
    "gauge_fixing": Assumption(
        "gauge_fixing", "gauge",
        "Gauge redundancy is partially fixed to define observables."
    ),
    "reference_fields": Assumption(
        "reference_fields", "relational",
        "Matter or reference fields exist to define relations."
    ),
    "observer_access": Assumption(
        "observer_access", "observer",
        "An observer can identify and correlate quantities."
    ),
    "stable_distinguishability": Assumption(
        "stable_distinguishability", "gauge",
        "A stable notion of distinguishability exists."
    ),
    "preferred_time": Assumption(
        "preferred_time", "background",
        "A time parameter exists to compare configurations."
    ),
}


# ---------------------------------------------------------------------
# Relational observable definitions
# ---------------------------------------------------------------------

definitions = [
    Concept(
        "relational_position_via_reference_fields",
        [
            assumptions["reference_fields"],
            assumptions["observer_access"],
            assumptions["gauge_fixing"],
        ],
    ),
    Concept(
        "clock_time_observable",
        [
            assumptions["reference_fields"],
            assumptions["preferred_time"],
            assumptions["observer_access"],
        ],
    ),
    Concept(
        "partial_observable_pairing",
        [
            assumptions["gauge_fixing"],
            assumptions["observer_access"],
        ],
    ),
    Concept(
        "fully_gauge_invariant_relational_quantity",
        [
            assumptions["stable_distinguishability"],
        ],
    ),
    Concept(
        "bare_invariant_label",
        [],
    ),
]


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 4 — T01 Relational Observable Definition Calibration\n")

    for d in definitions:
        print(f"Definition: {d.name}")
        if d.required_assumptions:
            print("  Requires:")
            for a in d.required_assumptions:
                print(f"   - {a.name} [{a.category}]")
        else:
            print("  Requires: (none)")
        print("")

    print(
        "Note:\n"
        "This toy does NOT decide which relational observables are useful.\n"
        "It only records what structure is required to even define them."
    )


if __name__ == "__main__":
    report()
