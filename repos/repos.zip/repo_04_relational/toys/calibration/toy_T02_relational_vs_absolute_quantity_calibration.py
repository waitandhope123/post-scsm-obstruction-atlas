"""
Repo 4 — T02 Relational vs Absolute Quantity Calibration

Purpose:
Compare absolute quantities with relational counterparts
and record what structure is required for each.
"""

from repo_04_relational.relational_foundations import Assumption, Concept


# ---------------------------------------------------------------------
# Assumptions
# ---------------------------------------------------------------------

assumptions = {
    "fixed_background": Assumption(
        "fixed_background", "background",
        "A fixed background structure exists."
    ),
    "reference_fields": Assumption(
        "reference_fields", "relational",
        "Reference entities exist to define relations."
    ),
    "observer_access": Assumption(
        "observer_access", "observer",
        "An observer can correlate quantities."
    ),
    "gauge_fixing": Assumption(
        "gauge_fixing", "gauge",
        "Gauge redundancy is partially fixed."
    ),
    "stable_distinguishability": Assumption(
        "stable_distinguishability", "gauge",
        "A stable notion of distinguishability exists."
    ),
}


# ---------------------------------------------------------------------
# Quantity comparison
# ---------------------------------------------------------------------

quantities = [
    Concept(
        "absolute_position_coordinate",
        [
            assumptions["fixed_background"],
        ],
    ),
    Concept(
        "relational_position_between_objects",
        [
            assumptions["reference_fields"],
            assumptions["observer_access"],
        ],
    ),
    Concept(
        "absolute_time_parameter",
        [
            assumptions["fixed_background"],
        ],
    ),
    Concept(
        "relational_time_via_clock",
        [
            assumptions["reference_fields"],
            assumptions["observer_access"],
        ],
    ),
    Concept(
        "fully_gauge_invariant_scalar_label",
        [
            assumptions["stable_distinguishability"],
        ],
    ),
]


# ---------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------

def report():
    print("\nRepo 4 — T02 Relational vs Absolute Quantity Calibration\n")

    for q in quantities:
        print(f"Quantity: {q.name}")
        if q.required_assumptions:
            print("  Requires:")
            for a in q.required_assumptions:
                print(f"   - {a.name} [{a.category}]")
        else:
            print("  Requires: (none)")
        print("")

    print(
        "Observation:\n"
        "- Absolute quantities rely on fixed background structure.\n"
        "- Relational quantities avoid absolute backgrounds but require\n"
        "  reference entities and observer correlation.\n"
        "- Fully invariant quantities tend to collapse into labels\n"
        "  with limited informational content."
    )


if __name__ == "__main__":
    report()
