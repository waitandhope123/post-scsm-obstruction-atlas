"""
Repo 4 — Relational Observables & Gauge Invariance
Foundational definitions and bookkeeping.

This module defines minimal data structures used by the toys.
It contains NO physics and NO dynamics.
"""

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class Assumption:
    name: str
    category: str
    description: str


@dataclass(frozen=True)
class Concept:
    name: str
    required_assumptions: List[Assumption]
