"""
Repo 5 — Obstruction Foundations

Purpose:
Provide common data structures for representing
no-go theorems, hard obstructions, soft obstructions,
and assumption-dependence maps across all repos.
"""

class Assumption:
    def __init__(self, name, category, description=""):
        self.name = name
        self.category = category
        self.description = description

    def __repr__(self):
        return f"{self.name} [{self.category}]"


class Obstruction:
    def __init__(
        self,
        name,
        obstruction_type,  # "hard" or "soft"
        violated_requirements,
        description="",
        source_repos=None,
    ):
        self.name = name
        self.obstruction_type = obstruction_type
        self.violated_requirements = violated_requirements
        self.description = description
        self.source_repos = source_repos or []

    def summary(self):
        return {
            "name": self.name,
            "type": self.obstruction_type,
            "violated_requirements": self.violated_requirements,
            "source_repos": self.source_repos,
        }


class ObstructionMap:
    def __init__(self):
        self.obstructions = []

    def add(self, obstruction):
        self.obstructions.append(obstruction)

    def hard_obstructions(self):
        return [o for o in self.obstructions if o.obstruction_type == "hard"]

    def soft_obstructions(self):
        return [o for o in self.obstructions if o.obstruction_type == "soft"]

    def report(self):
        print("\nObstruction Atlas Summary\n")

        print("HARD obstructions:\n")
        for o in self.hard_obstructions():
            print(f"- {o.name}")
            for r in o.source_repos:
                print(f"   • source: {r}")
        print("")

        print("SOFT obstructions:\n")
        for o in self.soft_obstructions():
            print(f"- {o.name}")
            for r in o.source_repos:
                print(f"   • source: {r}")

"""
Foundational structures for Repo 5 — Obstructions
"""

class Obstruction:
    def __init__(self, name, obstruction_type, description):
        self.name = name
        self.obstruction_type = obstruction_type  # HARD or SOFT
        self.description = description


class ObstructionEquivalenceClass:
    """
    Groups multiple obstructions that are logically equivalent,
    i.e. different manifestations of the same principle-level failure.
    """

    def __init__(self, name, members, core_violation):
        """
        name: str
            Name of the equivalence class
        members: list[str]
            Names of obstructions in this class
        core_violation: str
            The shared underlying impossibility
        """
        self.name = name
        self.members = members
        self.core_violation = core_violation
