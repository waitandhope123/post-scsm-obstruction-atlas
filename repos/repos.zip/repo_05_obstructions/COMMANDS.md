## Repo 5 — Obstructions

### Calibration
```bash
python -m repo_05_obstructions.toys.calibration.toy_T01_obstruction_definition_calibration
python -m repo_05_obstructions.toys.calibration.toy_T02_hard_vs_soft_obstruction_calibration
python -m repo_05_obstructions.toys.calibration.toy_T03_assumption_removal_dependency_calibration
python -m repo_05_obstructions.toys.calibration.toy_T04_obstruction_equivalence_class_calibration
python -m repo_05_obstructions.toys.calibration.toy_T05_obstruction_taxonomy_calibration
```

### Baseline Exclusions
```bash
python -m repo_05_obstructions.toys.baseline.toy_T06_obstruction_exclude_model_artifacts_baseline
python -m repo_05_obstructions.toys.baseline.toy_T07_obstruction_exclude_effective_only_baseline
python -m repo_05_obstructions.toys.baseline.toy_T08_obstruction_exclude_observer_limitations_baseline
python -m repo_05_obstructions.toys.baseline.toy_T09_obstruction_exclude_semiclassical_breakdown_baseline
python -m repo_05_obstructions.toys.baseline.toy_T10_obstruction_baseline_closure
```

### Stress Tests
```bash
python -m repo_05_obstructions.toys.stress.toy_T11_combined_assumption_stress
python -m repo_05_obstructions.toys.stress.toy_T12_relational_gauge_anchor_stress
python -m repo_05_obstructions.toys.stress.toy_T13_time_subsystem_boundary_stress
python -m repo_05_obstructions.toys.stress.toy_T14_maximal_charity_stress
python -m repo_05_obstructions.toys.stress.toy_T15_stress_phase_closure
```

### Synthesis
```bash
python -m repo_05_obstructions.toys.synthesis.toy_T16_global_minimal_requirements_synthesis
python -m repo_05_obstructions.toys.synthesis.toy_T17_necessary_vs_insufficient_structure_synthesis
python -m repo_05_obstructions.toys.synthesis.toy_T18_final_only_if_feasibility_boundary_synthesis
python -m repo_05_obstructions.toys.synthesis.toy_T19_obstruction_atlas_synthesis
python -m repo_05_obstructions.toys.synthesis.toy_T20_final_repo_closure
```
