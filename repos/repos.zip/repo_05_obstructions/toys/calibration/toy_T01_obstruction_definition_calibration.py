"""
Repo 5 — T01 Obstruction Definition Calibration

Purpose:
Clarify what counts as an obstruction, a no-go,
or merely an effective limitation.
"""

from repo_05_obstructions.obstruction_foundations import Obstruction

definitions = [
    (
        "hard_obstruction",
        "A principle-level impossibility that blocks formulation "
        "of a concept without reintroducing forbidden structure."
    ),
    (
        "soft_obstruction",
        "A gap where no construction is known, but no principle-level "
        "impossibility has been established."
    ),
    (
        "effective_failure",
        "A breakdown that occurs only when approximations or "
        "regime assumptions are exceeded."
    ),
    (
        "model_artifact",
        "A failure specific to a particular formalism or toy model."
    ),
]

def report():
    print("\nRepo 5 — T01 Obstruction Definition Calibration\n")

    for name, desc in definitions:
        print(f"Definition: {name}")
        print(f"  {desc}\n")

    print(
        "Note:\n"
        "Only HARD and SOFT obstructions are tracked in this repo.\n"
        "Effective failures and model artifacts are explicitly excluded."
    )


if __name__ == "__main__":
    report()
