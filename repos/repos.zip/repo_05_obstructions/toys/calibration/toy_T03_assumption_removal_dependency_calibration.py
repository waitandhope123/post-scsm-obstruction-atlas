"""
Repo 5 — T03 Assumption Removal Dependency Calibration

Purpose:
Map which HARD obstructions are triggered
by removal of specific structural assumptions.

This toy builds the dependency logic underlying
Repos 1–4 and prepares the obstruction atlas.
"""

from repo_05_obstructions.obstruction_foundations import Obstruction, ObstructionMap


def build_dependency_map():
    atlas = ObstructionMap()

    # -------------------------------------------------
    # Time / Ordering removal
    # -------------------------------------------------

    atlas.add(
        Obstruction(
            name="remove_time_triggers_persistence_failure",
            obstruction_type="hard",
            violated_requirements=["time_or_ordering_parameter"],
            description=(
                "Removing time/order makes persistence-as-information unformulable. "
                "No before/after comparison is possible."
            ),
            source_repos=["repo_02_persistence:T11", "repo_02_persistence:T20"],
        )
    )

    # -------------------------------------------------
    # Region / Subsystem removal
    # -------------------------------------------------

    atlas.add(
        Obstruction(
            name="remove_region_structure_triggers_locality_failure",
            obstruction_type="hard",
            violated_requirements=["region_or_equivalent_structure"],
            description=(
                "Without region- or support-like structure, locality claims "
                "and local disturbance definitions collapse."
            ),
            source_repos=["repo_03_locality:T12", "repo_03_locality:T20"],
        )
    )

    atlas.add(
        Obstruction(
            name="remove_region_structure_triggers_qec_failure",
            obstruction_type="hard",
            violated_requirements=["subsystem_or_equivalent_structure"],
            description=(
                "QEC requires a subsystem or equivalent structure to define "
                "noise, error sets, and recovery."
            ),
            source_repos=["repo_01_qgec:T07", "repo_01_qgec:T16"],
        )
    )

    # -------------------------------------------------
    # Reference / Anchor removal
    # -------------------------------------------------

    atlas.add(
        Obstruction(
            name="remove_reference_structure_triggers_relational_collapse",
            obstruction_type="hard",
            violated_requirements=["reference_or_anchor_structure"],
            description=(
                "Relational observables collapse without reference or anchoring "
                "structures to stabilize meaning."
            ),
            source_repos=["repo_04_relational:T11", "repo_04_relational:T20"],
        )
    )

    atlas.add(
        Obstruction(
            name="remove_reference_structure_triggers_persistence_failure",
            obstruction_type="hard",
            violated_requirements=["reference_or_observer_structure"],
            description=(
                "Persistence-as-information requires reference or observer structure "
                "to enable retrieval and comparison."
            ),
            source_repos=["repo_02_persistence:T12", "repo_02_persistence:T17"],
        )
    )

    # -------------------------------------------------
    # Enforce full gauge invariance
    # -------------------------------------------------

    atlas.add(
        Obstruction(
            name="full_gauge_invariance_trivializes_information",
            obstruction_type="hard",
            violated_requirements=["stable_distinguishability"],
            description=(
                "Full gauge invariance identifies or averages over distinctions, "
                "collapsing information-bearing structures into equivalence classes."
            ),
            source_repos=[
                "repo_01_qgec:T13",
                "repo_02_persistence:T13",
                "repo_03_locality:T13",
                "repo_04_relational:T12",
            ],
        )
    )

    return atlas


def report(atlas: ObstructionMap):
    print("\nRepo 5 — T03 Assumption Removal Dependency Calibration\n")

    print(
        "Principle:\n"
        "If removing an assumption immediately triggers a HARD obstruction,\n"
        "then that assumption is logically necessary for formulation.\n"
    )

    for o in atlas.hard_obstructions():
        print(f"- {o.name}")
        print(f"  Triggered by removing: {', '.join(o.violated_requirements)}")
        print("  Established in:")
        for s in o.source_repos:
            print(f"   • {s}")
        if o.description:
            print(f"  Explanation: {o.description}")
        print("")

    print(
        "Note:\n"
        "This toy does NOT claim the assumptions are fundamental.\n"
        "It shows that removing them triggers definitional collapse."
    )


if __name__ == "__main__":
    atlas = build_dependency_map()
    report(atlas)
