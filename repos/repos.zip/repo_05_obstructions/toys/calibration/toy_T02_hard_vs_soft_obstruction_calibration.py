"""
Repo 5 — T02 Hard vs Soft Obstruction Calibration

Purpose:
Calibrate the distinction between HARD and SOFT obstructions
using representative examples drawn from Repos 1–4.

This toy does NOT prove new theorems.
It standardizes classification criteria for the obstruction atlas.
"""

from repo_05_obstructions.obstruction_foundations import Obstruction, ObstructionMap


def build_examples():
    atlas = ObstructionMap()

    # ---------------------------
    # HARD obstructions (principle-level)
    # ---------------------------

    atlas.add(
        Obstruction(
            name="no_qec_without_noise_and_recovery_interface",
            obstruction_type="hard",
            violated_requirements=[
                "noise_interface_definability",
                "recovery_or_retrieval_map_definability",
            ],
            description=(
                "If 'noise' and 'recovery' are not even definable, then the core QEC claim "
                "('corrects error set E') collapses as a statement."
            ),
            source_repos=["repo_01_qgec:T12", "repo_01_qgec:T16", "repo_01_qgec:T20"],
        )
    )

    atlas.add(
        Obstruction(
            name="no_persistence_without_time_or_ordering",
            obstruction_type="hard",
            violated_requirements=[
                "time_or_ordering_parameter",
            ],
            description=(
                "Persistence-as-information requires an ordering notion. "
                "Without any time/order, persistence is not formulable."
            ),
            source_repos=["repo_02_persistence:T11", "repo_02_persistence:T16", "repo_02_persistence:T20"],
        )
    )

    atlas.add(
        Obstruction(
            name="no_locality_without_region_or_equivalent_structure",
            obstruction_type="hard",
            violated_requirements=[
                "region_or_equivalent_structure",
                "disturbance_interface_definability",
            ],
            description=(
                "Locality claims require a support/region notion. "
                "Without region-equivalent structure, 'local disturbance' is undefined."
            ),
            source_repos=["repo_03_locality:T12", "repo_03_locality:T16", "repo_03_locality:T20"],
        )
    )

    atlas.add(
        Obstruction(
            name="relational_observables_trivialize_under_full_gauge_invariance",
            obstruction_type="hard",
            violated_requirements=[
                "nontrivial_informational_capacity",
                "stable_identity",
            ],
            description=(
                "Full gauge invariance enforces equivalence by identifying/averaging relational distinctions, "
                "collapsing information content into labels/equivalence classes."
            ),
            source_repos=["repo_04_relational:T12", "repo_04_relational:T15", "repo_04_relational:T20"],
        )
    )

    # ---------------------------
    # SOFT obstructions (unknown constructions; not ruled out in principle)
    # ---------------------------

    atlas.add(
        Obstruction(
            name="unknown_invariant_anchor_mechanisms",
            obstruction_type="soft",
            violated_requirements=[
                "reference_or_anchor_structure",
            ],
            description=(
                "Known successful constructions use boundaries/reference fields, but it remains logically possible "
                "that new invariant anchoring mechanisms exist (not currently known)."
            ),
            source_repos=["repo_01_qgec:T18", "repo_03_locality:T18", "repo_04_relational:T17"],
        )
    )

    atlas.add(
        Obstruction(
            name="non_semiclassical_stable_information_regime_not_exhibited",
            obstruction_type="soft",
            violated_requirements=[
                "semiclassical_or_effective_regime",
            ],
            description=(
                "All working notions of protected information/persistence/locality/relational observables "
                "appear effective or semiclassical. A non-semiclassical stable regime is not exhibited here "
                "but not ruled out by a universal theorem."
            ),
            source_repos=["repo_01_qgec:T10", "repo_02_persistence:T18", "repo_03_locality:T10", "repo_04_relational:T18"],
        )
    )

    return atlas


def report(atlas: ObstructionMap):
    print("\nRepo 5 — T02 Hard vs Soft Obstruction Calibration\n")

    print("Calibration rule of thumb:\n")
    print("- HARD: the concept is not even FORMULABLE without reintroducing forbidden structure.")
    print("- SOFT: no construction is known, but impossibility is not established.\n")

    print("Representative HARD obstructions:\n")
    for o in atlas.hard_obstructions():
        print(f"- {o.name}")
        print(f"  Violates: {', '.join(o.violated_requirements)}")
        print("  Sources:")
        for s in o.source_repos:
            print(f"   • {s}")
        if o.description:
            print(f"  Note: {o.description}")
        print("")

    print("Representative SOFT obstructions:\n")
    for o in atlas.soft_obstructions():
        print(f"- {o.name}")
        print(f"  Blocks: {', '.join(o.violated_requirements)}")
        print("  Sources:")
        for s in o.source_repos:
            print(f"   • {s}")
        if o.description:
            print(f"  Note: {o.description}")
        print("")

    print(
        "Note:\n"
        "This toy calibrates classification only.\n"
        "Repo 5 will later build the full atlas systematically (T19)."
    )


if __name__ == "__main__":
    atlas = build_examples()
    report(atlas)
