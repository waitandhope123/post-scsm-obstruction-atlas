"""
Repo 5 — T06 Exclude Model Artifacts (Baseline)

Purpose:
Explicitly exclude failures that arise only from specific models,
toy constructions, or formal choices.

These are NOT treated as fundamental obstructions in the atlas.
"""

def report():
    print("\nRepo 5 — T06 Exclude Model Artifacts (Baseline)\n")

    excluded = [
        "specific_holographic_code_failure",
        "toy_model_quantization_artifact",
        "lattice_discretization_failure",
        "formalism_specific_operator_pathology",
    ]

    print("Excluded failure types (NOT obstructions):\n")

    for item in excluded:
        print(f" • {item}")

    print(
        "\nRationale:\n"
        "Failures tied to specific models, discretizations, or formalisms\n"
        "do not establish principle-level impossibility.\n\n"
        "Repo 5 tracks only HARD and SOFT obstructions that survive\n"
        "model changes and formal re-descriptions."
    )


if __name__ == "__main__":
    report()
