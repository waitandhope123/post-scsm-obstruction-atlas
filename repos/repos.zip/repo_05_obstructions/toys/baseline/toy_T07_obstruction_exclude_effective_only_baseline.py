"""
Repo 5 — T07 Exclude Effective-Only Failures (Baseline)

Purpose:
Exclude failures that arise only when effective, semiclassical,
or observer-dependent scaffolding is removed.

These are NOT counted as fundamental obstructions.
They instead define the scope of validity of effective concepts.
"""

def report():
    print("\nRepo 5 — T07 Exclude Effective-Only Failures (Baseline)\n")

    excluded = [
        "standard_qec_effective_only",
        "semiclassical_persistence_effective_only",
        "semiclassical_locality_effective_only",
        "semiclassical_relational_observables_effective_only",
    ]

    print("Excluded failure types (effective-only, NOT obstructions):\n")

    for item in excluded:
        print(f" • {item}")

    print(
        "\nRationale:\n"
        "These failures indicate that a concept does not survive\n"
        "removal of effective scaffolding (time, observers, locality,\n"
        "semiclassical geometry).\n\n"
        "This does NOT establish impossibility.\n"
        "It only establishes non-fundamentality.\n\n"
        "Repo 5 tracks only failures that prevent formulation\n"
        "even before effective regimes are invoked."
    )


if __name__ == "__main__":
    report()
