"""
toy_T03_semiclassical_vs_fundamental_dynamics_calibration.py

Repo 6 — T03 Semiclassical vs Fundamental Dynamics Calibration

Purpose:
Record which notions of dynamics (evolution, history, trajectory)
are available in semiclassical/effective regimes versus
fully background-free, gauge-invariant regimes.
"""

from repo_06_semiclassical_vs_fundamental.semiclassical_foundations import (
    Assumption,
    Concept,
    print_concept_summary,
)


def main():
    print("\nRepo 6 — T03 Semiclassical vs Fundamental Dynamics Calibration\n")

    # --- Assumptions ---

    preferred_time = Assumption(
        name="preferred_time",
        category="background",
        description="A global or effective time parameter exists."
    )

    relational_time = Assumption(
        name="relational_time",
        category="relational",
        description="Time is defined relationally via clocks or correlations."
    )

    semiclassical_limit = Assumption(
        name="semiclassical_limit",
        category="semiclassical",
        description="An effective regime with approximate classical behavior."
    )

    stable_distinguishability = Assumption(
        name="stable_distinguishability",
        category="gauge",
        description="States remain distinguishable across evolution."
    )

    full_gauge_invariance = Assumption(
        name="full_gauge_invariance",
        category="gauge",
        description="Only fully gauge-invariant quantities are physical."
    )

    # --- Dynamics notions ---

    classical_time_evolution = Concept(
        name="classical_time_evolution",
        requires=[
            preferred_time,
            stable_distinguishability,
        ]
    )

    relational_dynamics = Concept(
        name="relational_dynamics",
        requires=[
            relational_time,
            semiclassical_limit,
            stable_distinguishability,
        ]
    )

    fully_invariant_dynamics = Concept(
        name="fully_gauge_invariant_dynamics",
        requires=[
            full_gauge_invariance,
        ]
    )

    # --- Output ---

    print_concept_summary(classical_time_evolution)
    print()
    print_concept_summary(relational_dynamics)
    print()
    print_concept_summary(fully_invariant_dynamics)

    print(
        "\nObservation:\n"
        "Classical and relational notions of dynamics rely on time parameters,\n"
        "distinguishability, and effective stability.\n"
        "When full gauge invariance is enforced, evolution typically reduces\n"
        "to relations between equivalence classes rather than trajectories.\n\n"
        "This toy does NOT claim dynamics is impossible.\n"
        "It records that familiar dynamical notions are not primitive\n"
        "in fully background-free, gauge-invariant formulations."
    )


if __name__ == "__main__":
    main()
