"""
toy_T01_semiclassical_definition_calibration.py

Repo 6 — T01 Semiclassical Definition Calibration

Purpose:
Calibrate what is meant by "semiclassical", "effective", and "fundamental"
without assuming any of them are physically privileged.

This toy ONLY records what structure is required to even state these notions.
It does not argue that any regime is correct or fundamental.
"""

from repo_06_semiclassical_vs_fundamental.semiclassical_foundations import (
    Assumption,
    Concept,
    print_concept_summary,
)


def main():
    print("\nRepo 6 — T01 Semiclassical Definition Calibration\n")

    # --- Assumptions used in defining regimes ---

    semiclassical_limit = Assumption(
        name="semiclassical_limit",
        category="semiclassical",
        description="An effective regime where quantum fields propagate on approximately classical spacetime."
    )

    effective_background = Assumption(
        name="effective_background",
        category="background",
        description="Approximate background structures (time, geometry, causality) are treated as stable."
    )

    coarse_graining = Assumption(
        name="coarse_graining",
        category="observer",
        description="Degrees of freedom are grouped or averaged to suppress microscopic fluctuations."
    )

    observer_access = Assumption(
        name="observer_access",
        category="observer",
        description="Observers exist who can operationally access and compare states."
    )

    full_gauge_invariance = Assumption(
        name="full_gauge_invariance",
        category="gauge",
        description="Only fully gauge- and diffeomorphism-invariant quantities are physical."
    )

    # --- Regime concepts ---

    semiclassical_regime = Concept(
        name="semiclassical_regime",
        requires=[
            semiclassical_limit,
            effective_background,
            coarse_graining,
            observer_access
        ]
    )

    effective_regime = Concept(
        name="effective_regime",
        requires=[
            effective_background,
            coarse_graining,
            observer_access
        ]
    )

    fundamental_regime = Concept(
        name="fundamental_background_free_regime",
        requires=[
            full_gauge_invariance
        ]
    )

    # --- Output ---

    print_concept_summary(semiclassical_regime)
    print()
    print_concept_summary(effective_regime)
    print()
    print_concept_summary(fundamental_regime)

    print(
        "\nNote:\n"
        "This toy does NOT claim that semiclassical or effective regimes are fundamental.\n"
        "It records that these regimes require additional stabilizing assumptions\n"
        "that are absent in a fully background-free, gauge-invariant formulation."
    )


if __name__ == "__main__":
    main()
