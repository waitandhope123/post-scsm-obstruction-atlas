"""
toy_T02_effective_vs_fundamental_distinguishability_calibration.py

Repo 6 — T02 Effective vs Fundamental Distinguishability Calibration

Purpose:
Calibrate which notions of distinguishability are available
in effective/semiclassical regimes versus fully background-free,
gauge-invariant regimes.

This toy records assumption-dependence only.
"""

from repo_06_semiclassical_vs_fundamental.semiclassical_foundations import (
    Assumption,
    Concept,
    print_concept_summary,
)


def main():
    print("\nRepo 6 — T02 Effective vs Fundamental Distinguishability Calibration\n")

    # --- Assumptions ---

    stable_inner_product = Assumption(
        name="stable_inner_product",
        category="gauge",
        description="A fixed notion of state overlap or distinguishability exists."
    )

    operational_measurement = Assumption(
        name="operational_measurement",
        category="observer",
        description="Measurements can be performed to distinguish outcomes."
    )

    semiclassical_limit = Assumption(
        name="semiclassical_limit",
        category="semiclassical",
        description="An effective regime with approximately classical structure."
    )

    full_gauge_invariance = Assumption(
        name="full_gauge_invariance",
        category="gauge",
        description="Only fully gauge-invariant quantities are physical."
    )

    # --- Distinguishability notions ---

    operational_distinguishability = Concept(
        name="operational_state_distinguishability",
        requires=[
            stable_inner_product,
            operational_measurement,
            semiclassical_limit,
        ]
    )

    kinematic_distinguishability = Concept(
        name="kinematic_hilbert_space_distinguishability",
        requires=[
            stable_inner_product,
        ]
    )

    fully_invariant_distinguishability = Concept(
        name="fully_gauge_invariant_distinguishability",
        requires=[
            full_gauge_invariance,
        ]
    )

    # --- Output ---

    print_concept_summary(operational_distinguishability)
    print()
    print_concept_summary(kinematic_distinguishability)
    print()
    print_concept_summary(fully_invariant_distinguishability)

    print(
        "\nObservation:\n"
        "Operational and kinematic distinguishability rely on inner products,\n"
        "measurement access, or semiclassical stability.\n"
        "When full gauge invariance is enforced, distinguishability typically\n"
        "collapses to equivalence classes or invariant labels.\n\n"
        "This toy does NOT claim distinguishability is impossible.\n"
        "It records that known forms of distinguishability are not\n"
        "available as primitive structures in fully background-free physics."
    )


if __name__ == "__main__":
    main()
