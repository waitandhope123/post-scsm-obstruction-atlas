"""
semiclassical_foundations.py

Foundational primitives for Repo 6:
Semiclassical vs Fundamental Survivability Analysis

This file defines ONLY classification and bookkeeping structures.
It introduces no physical claims, dynamics, or models.

Repo 6 asks:
Which structures survive ONLY because we are in a semiclassical or effective regime,
and which collapse when those approximations are removed?
"""


class Assumption:
    """
    Represents an assumption required to define or stabilize a concept.

    Parameters
    ----------
    name : str
        Short identifier for the assumption.
    category : str
        Classification category (e.g. background, observer, gauge, semiclassical).
    description : str
        Human-readable explanation of the assumption.
    """

    def __init__(self, name: str, category: str, description: str):
        self.name = name
        self.category = category
        self.description = description

    def __repr__(self):
        return f"{self.name} [{self.category}]"


class Concept:
    """
    Represents a conceptual structure whose survivability is being tested.

    Parameters
    ----------
    name : str
        Name of the concept.
    requires : list[Assumption]
        Assumptions required to even formulate the concept.
    """

    def __init__(self, name: str, requires=None):
        self.name = name
        self.requires = requires or []

    def __repr__(self):
        return self.name


class RegimeTag:
    """
    Tags indicating the regime in which a concept is definable or stable.
    """

    SEMICLASSICAL = "semiclassical"
    EFFECTIVE = "effective"
    FUNDAMENTAL = "fundamental"


class SurvivalStatus:
    """
    Classification of whether a concept survives beyond the semiclassical regime.
    """

    SURVIVES_EFFECTIVELY = "survives_effectively"
    COLLAPSES_FUNDAMENTALLY = "collapses_fundamentally"
    UNDETERMINED = "undetermined"


def print_concept_summary(concept: Concept):
    """
    Utility printer for toy scripts.
    """
    print(f"Concept: {concept.name}")
    if concept.requires:
        print("  Requires:")
        for req in concept.requires:
            print(f"   - {req}")
    else:
        print("  Requires: (none)")


def print_survival_classification(concept: Concept, regime: str, status: str):
    """
    Utility printer for survivability classification.
    """
    print(f"\nSurvivability Classification:")
    print(f" Concept: {concept.name}")
    print(f" Regime tested: {regime}")
    print(f" Outcome: {status}")
